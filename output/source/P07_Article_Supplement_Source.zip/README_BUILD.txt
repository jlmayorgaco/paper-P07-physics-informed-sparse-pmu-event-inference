P07 article and supplement source snapshot

Compile main.tex and supplement.tex separately with pdfLaTeX, BibTeX and two
further pdfLaTeX passes. IEEEtran.bst may be supplied by your TeX distribution.
All local files actually read by these builds are included with their paths.
Comparator provenance is independently regenerated, without models or PMU data,
with Python: python scripts/build_comparator_lineage.py.
Local mathematical checks use the bundled verified kernel:
python scripts/verify_history_partition.py (requires NumPy and SciPy).
These small checks do not rerun the nonlinear scientific campaigns.
The PDF copies are supplied separately in output/pdf in the working repository.

This is a review snapshot, not a certificate of submission readiness. C01 and
A01 are complete frozen evidence. Additional independent calibration and
matched-comparator validation, and final author declarations, remain subject
to the current repository status. No external submission is performed.
Historical Technical Notes are preserved as a separate repository document.
