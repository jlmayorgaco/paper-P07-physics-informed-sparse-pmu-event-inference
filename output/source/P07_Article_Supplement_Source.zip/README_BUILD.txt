P07 article and supplement source snapshot

Compile main.tex and supplement.tex separately with pdfLaTeX, BibTeX and two
further pdfLaTeX passes. IEEEtran.bst may be supplied by your TeX distribution.
All local files actually read by these builds are included with their paths.
Comparator provenance is independently regenerated, without models or PMU data,
with Python: python scripts/build_comparator_lineage.py.
The editable overview and physical/report diagrams are TikZ vector figures.
Regenerate them with python scripts/build_recovery_overview.py and
python scripts/build_physics_measurement_chain.py (pdfLaTeX and PyMuPDF required).
The current half-page Figure 1 is built by:
python scripts/build_paper_method_figure.py
Local mathematical checks use the bundled verified kernel:
python scripts/verify_history_partition.py (requires NumPy and SciPy).
Predictive sufficiency, mixture moments and deterministic post-processing have
small finite-enumeration checks: python scripts/verify_recovery_distribution.py.
These small checks do not rerun the nonlinear scientific campaigns.
The deterministic terminal-current diagnostic reproduces from its compact
operator snapshot, without the scientific repository or campaign files:
python experiments/channel_information_20261112/run_channel_diagnostic.py
python scripts/build_channel_information_figure.py
The bounded-rival severity successor uses the same nominal snapshot:
python experiments/channel_profile_20261112/run.py
python scripts/build_channel_profile_figure.py
Independent illustrative Gaussian/energy checks (not IEEE-39 outcomes):
python experiments/hbg_verification_20261112/verify_extended.py
See that experiment's README for dependencies and the fixed-mean scope.
The PDF copies are supplied separately in output/pdf in the working repository.

This is a review snapshot, not a certificate of submission readiness. C01 and
A01, B01 and C02 are complete frozen evidence. The successor mechanism and
transfer study, and final author declarations, remain subject
to the current repository status. No external submission is performed.
Historical Technical Notes are preserved as a separate repository document.
