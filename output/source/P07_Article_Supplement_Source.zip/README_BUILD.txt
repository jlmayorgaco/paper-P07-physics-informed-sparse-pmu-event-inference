P07 article and supplement source snapshot

Compile main.tex and supplement.tex separately with pdfLaTeX, BibTeX and two
further pdfLaTeX passes. IEEEtran.bst may be supplied by your TeX distribution.
All local files actually read by these builds are included with their paths.
The PDF copies are supplied separately in output/pdf in the working repository.

This is a review snapshot, not a certificate of submission readiness. The
confirmatory campaign is complete; scientific interpretation, references,
and final author metadata/biographies remain subject to coauthor review.
No external submission is performed.
Historical Technical Notes are preserved as a separate repository document.
