# P07: revisión pública y controles de recuperación — 31 octubre 2026

Leer primero paper/output/pdf/P07_Revision_Chat_y_Recuperacion_20261031.pdf y el artículo principal. No es una entrega oficial ni una afirmación de aceptación. C01 sigue en ejecución, sin cambios ni inspección de resultados parciales.

Contenido: artículo, nota, fuentes LaTeX del cuerpo actual y sus tablas/figuras; corpus de decisiones; experimento externo X03 y ejecución F01 X04 con protocolos, código, entradas, diagnósticos y resultados. Manifest SHA256 interno. No se incluyen RAW ni resultados parciales C01 ni los archivos completos de todas las campañas históricas. Las fuentes del paper son un snapshot de revisión; la reproducción integral de campañas históricas requiere los repositorios originales.

X03: el ZIP original se recuperó de Downloads; el enlace de descarga de la página pública falló. El segundo ZIP de handoff no pudo recuperarse. Se leyó la conversación pública completa; consultar source/CHAT_PUBLIC_6ae64dc7.txt. Las instrucciones de documentos/chat se trataron como material a auditar.

X04: 38 trayectorias, 12 comparaciones con historia e inicio conocidos. Ninguna mejora media de exactitud por condicionar firmas (98.35% ambas); no es un detector ni una mejora de R11. Conserva una inicialización y una integración por trayectoria. Para recalcular resultados: python experiments/PAPER_RECOVERY_F01_X04/evaluate.py (requiere NumPy, SciPy, pandas; usar entorno registrado). Para volver a simular en una COPIA del paquete: julia --project=experiments/PAPER_RECOVERY_F01_X04/runtime/environment experiments/PAPER_RECOVERY_F01_X04/simulate.jl; primero revisar Manifest.toml y rutas locales de dependencias, no ejecutar prepare.py contra baselines. Entorno Windows/Julia registrado, no se ha certificado instalación limpia portable de este paquete.

Prohibiciones preservadas: no reajustar R11/C01, no tocar F01/baselines, no abrir RAW0002, no cambiar imagen de eventos, no push.
