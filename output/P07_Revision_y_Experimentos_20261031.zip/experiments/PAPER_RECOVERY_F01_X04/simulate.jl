# New candidate outputs only. The parent driver's functions are reused, not its main.
using IEEE39,PowerDynamics,NetworkDynamics,OrdinaryDiffEqRosenbrock,OrdinaryDiffEqNonlinearSolve
using CSV,DataFrames,JSON,LinearAlgebra,SHA
using NetworkDynamics: SII
const CAND=@__DIR__
BLAS.set_num_threads(1)
parent=joinpath(CAND,"runtime/parent_run_op_noise.jl")
driver=first(split(read(parent,String),"\nfunction op_main()"))
@assert occursin("function initialize_operating_point",driver)
driver=replace(driver,"const ROOT = @__DIR__"=>"const ROOT = joinpath(CAND,\"engine\")")
driver=replace(driver,"const REF = joinpath(ROOT,\"reference\")"=>"const REF = joinpath(CAND,\"runtime/reference\")")
include_string(Main,driver,parent)

function campaign()
    cfg=JSON.parsefile(joinpath(ROOT,"REQUEST.json"));nw,sbase=initialize_frozen();ops=Dict()
    for op in cfg["operating_points"]
        try
            ops[op["id"]]=initialize_operating_point(nw,sbase,op)
        catch err
            path=joinpath(ROOT,"operating_points",op["id"]);mkpath(path)
            jsonwrite(joinpath(path,"REJECTED.json"),Dict("error"=>sprint(showerror,err)))
        end
    end
    for (k,case) in enumerate(cfg["cases"])
        out=joinpath(ROOT,"events/diagnostics",case["id"]);mkpath(out)
        if !isfile(joinpath(out,"status.json")) && !isfile(joinpath(out,"REJECTED.json"))
            try
                @assert haskey(ops,case["operating_point"])
                run_case(nw,ops[case["operating_point"]],cfg,case)
            catch err
                jsonwrite(joinpath(out,"REJECTED.json"),Dict("error"=>sprint(showerror,err)))
                println("CASE_REJECTED ",case["id"]," ",sprint(showerror,err));flush(stdout)
            end
        end
        jsonwrite(joinpath(ROOT,"PROGRESS.json"),Dict("completed"=>k,"intended"=>length(cfg["cases"]),"last_case"=>case["id"]))
        GC.gc()
    end
end
campaign()
