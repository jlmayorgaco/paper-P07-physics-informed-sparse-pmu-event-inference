using IEEE39, PowerDynamics, NetworkDynamics
using OrdinaryDiffEqRosenbrock, OrdinaryDiffEqNonlinearSolve
using CSV, DataFrames, JSON, LinearAlgebra, SHA
using NetworkDynamics: SII
const SB = NetworkDynamics.SciMLBase
const ROOT = @__DIR__
const REF = joinpath(ROOT,"reference")
jsonwrite(path,x)=open(io->JSON.print(io,x,2),path,"w")

function initialize_frozen()
    for f in readdir(joinpath(REF,"ieee39_source"))
        @assert sha256(read(joinpath(pkgdir(IEEE39),"src",f))) == sha256(read(joinpath(REF,"ieee39_source",f)))
    end
    println("BUILD_FROZEN_PLANT");flush(stdout)
    nw=IEEE39.set_IEEE39_PF_init(IEEE39.get_IEEE39_base())
    archived=CSV.read(joinpath(REF,"pd_static_solution.csv"),DataFrame)
    for b in (31,39)
        row=archived[archived.bus.==b,:][1,:]
        set_default!(nw[VIndex(b)],:ZIPLoad₊Vset,hypot(row.u_r,row.u_i))
    end
    pfnw=powerflow_model(nw);pfs0=NWState(pfnw)
    targets=CSV.read(joinpath(REF,"target_bus_state.csv"),DataFrame)
    buses=CSV.read(joinpath(REF,"data","bus.csv"),DataFrame)
    for row in eachrow(buses)
        b=Int(row.bus);r=targets[targets.bus.==b,:][1,:]
        if row.bus_type=="PQ"
            pfs0.v[b].p[:pq₊P]=r.p_injection_pu;pfs0.v[b].p[:pq₊Q]=r.q_injection_pu
        elseif row.bus_type=="PV"
            pfs0.v[b].p[:pv₊P]=r.p_injection_pu;pfs0.v[b].p[:pv₊V]=r.vm_pu
        else
            pfs0.v[b].p[:slack₊V]=r.vm_pu
        end
    end
    pfs=solve_powerflow(nw;pfnw,pfs0,verbose=false)
    s0=initialize_from_pf!(nw;pfs,verbose=false)
    old_u=CSV.read(joinpath(REF,"initial_state.csv"),DataFrame)
    old_p=CSV.read(joinpath(REF,"initial_parameters.csv"),DataFrame)
    @assert string.(SII.variable_symbols(nw))==old_u.symbol
    @assert string.(SII.parameter_symbols(nw))==old_p.symbol
    udiff=maximum(abs.(uflat(s0).-old_u.value));pdiff=maximum(abs.(pflat(s0).-old_p.value))
    @assert udiff<1e-10 && pdiff<1e-10
    # Use the archived vectors exactly after checking fresh recovery.
    uflat(s0).=old_u.value;pflat(s0).=old_p.value
    du=zeros(length(uflat(s0)));nw(du,uflat(s0),pflat(s0),0.)
    jsonwrite(joinpath(ROOT,"diagnostics","frozen_initialization.json"),Dict(
        "recovered_state_max_difference"=>udiff,"recovered_parameters_max_difference"=>pdiff,
        "used_exact_archived_vectors"=>true,"initial_residual"=>maximum(abs,du),
        "julia"=>string(VERSION),"PowerDynamics"=>string(Base.pkgversion(PowerDynamics)),
        "NetworkDynamics"=>string(Base.pkgversion(NetworkDynamics)),"IEEE39"=>string(Base.pkgversion(IEEE39))))
    println("INITIAL_STATE_VERIFIED");flush(stdout)
    return nw,s0
end

function run_case(nw,s0,cfg,case)
    id=case["id"];out=joinpath(ROOT,"events","diagnostics",id);mkpath(out)
    duration=Float64(case["duration_s"]);loads=Int.(cfg["load_buses"])
    pmus=Int.(cfg["pmus"])
    schedule=case["actions"];updates=sort(unique(Float64(a["time_s"]) for a in schedule))
    times=collect(0:1/30:duration)
    u0=copy(uflat(s0));p0=copy(pflat(s0))
    ip=[SII.parameter_index(nw,VIndex(b,:ZIPLoad₊Pset)) for b in loads]
    iq=[SII.parameter_index(nw,VIndex(b,:ZIPLoad₊Qset)) for b in loads]
    indices=[SII.parameter_index(nw,a["kind"]=="vertex" ? VIndex(Int(a["asset"]),Symbol(a["parameter"])) : EIndex(Int(a["asset"]),Symbol(a["parameter"]))) for a in schedule]
    allowed=sort(unique(indices));fixed=setdiff(1:length(p0),allowed)
    event_before=Dict{Float64,Vector{Float64}}();param_history=Dict{Float64,Vector{Float64}}(0.0 => copy(p0))
    function update!(integ)
        tt=Float64(integ.t);event_before[tt]=copy(integ.u)
        for (a,idx) in zip(schedule,indices)
            if abs(Float64(a["time_s"])-tt)<1e-9
                integ.p[idx]=a["mode"]=="factor" ? p0[idx]*a["value"] : a["value"]
            end
        end
        @assert integ.p[fixed]==p0[fixed]
        @assert integ.u==event_before[tt] # no dynamic-state assignment in the input operator
        param_history[tt]=copy(integ.p)
        save_parameters!(integ)
        SB.auto_dt_reset!(integ)
        SB.u_modified!(integ,true)
        if Int(round(tt))%50==0;println("UPDATE ",id," t=",tt);flush(stdout);end
    end
    cb=IEEE39.DiffEqCallbacks.PresetTimeCallback(updates,update!;save_positions=(true,true))
    prob=ODEProblem(nw,u0,(0.,duration),copy(p0);add_nw_cb=cb)
    mass=diag(Matrix(prob.f.mass_matrix));dyn=findall(!iszero,mass);alg=findall(iszero,mass)
    println("SOLVE_START ",id);flush(stdout)
    elapsed=@elapsed sol=solve(prob,Rodas5P();abstol=1e-9,reltol=1e-9,dtmax=1/60,saveat=times,
                              save_everystep=false,maxiters=10^7)
    success=string(sol.retcode)=="Success"
    jsonwrite(joinpath(out,"solver_status.json"),Dict("retcode"=>string(sol.retcode),"elapsed_seconds"=>elapsed))
    @assert success
    mapping=CSV.read(joinpath(REF,"terminal_mapping.csv"),DataFrame)
    # Exact saved report states only. At duplicate event timestamps choose the
    # final post-consistency state; interpolation across an input jump is forbidden.
    state_by_tick=Dict{Int,Int}()
    for (k,t) in enumerate(sol.t)
        tick=round(Int,t*30)
        if abs(t-tick/30)<1e-8;state_by_tick[tick]=k;end
    end
    @assert length(state_by_tick)==length(times)
    current_get=SII.getsym(nw,[EIndex(Int(r.julia_edge_1based),Symbol(r.side,"₊i_",part)) for r in eachrow(mapping) for part in ("r","i")])
    voltage_get=SII.getsym(nw,[VIndex(b,Symbol("busbar₊u_",part)) for b in 1:39 for part in ("r","i")])
    load_get=SII.getsym(nw,[VIndex(b,Symbol("ZIPLoad₊",part)) for b in loads for part in ("P","Q")])
    operator_get=SII.getsym(nw,[EIndex(Int(cfg["line_edge_1based"]),Symbol(side,"₊i_",part)) for side in ("src","dst") for part in ("r","i")]);operator_current=zeros(length(times),4)
    operated_edges=sort(unique(Int(a["asset"]) for a in schedule if a["kind"]=="edge"))
    all_operator_current=zeros(length(times),4length(operated_edges))
    all_operator_get=isempty(operated_edges) ? nothing : SII.getsym(nw,[EIndex(e,Symbol(side,"₊i_",part)) for e in operated_edges for side in ("src","dst") for part in ("r","i")])
    volt=zeros(length(times),78);curr=zeros(length(times),16);actual_load=zeros(length(times),2length(loads))
    selected=findall(s->occursin("machine",string(s))&&(endswith(string(s),"ω)")||occursin("δ",string(s))),SII.variable_symbols(nw))
    # Keep all differential states for continuity and later physical diagnostics.
    dynamic=zeros(length(times),length(dyn));max_alg=0.;max_terminal=0.
    derivative=zeros(length(u0));allowed_delta=0.
    for (k,t) in enumerate(times)
        u=sol.u[state_by_tick[k-1]]
        eventtime=maximum(tt for tt in keys(param_history) if tt<=t+1e-9)
        p=param_history[eventtime]
        state=NWState(nw,u,p,t)
        volt[k,:]=voltage_get(state);curr[k,:]=current_get(state);actual_load[k,:]=load_get(state)
        dynamic[k,:]=u[dyn];operator_current[k,:]=operator_get(state)
        !isempty(operated_edges) && (all_operator_current[k,:]=all_operator_get(state))
        nw(derivative,u,p,t);max_alg=max(max_alg,maximum(abs,derivative[alg]))
        allowed_delta=max(allowed_delta,maximum(abs.(p[fixed].-p0[fixed])))
    end
    CSV.write(joinpath(out,"voltage_all_pu.csv"),hcat(DataFrame(time_s=times),DataFrame(volt,[Symbol("BUS",b,"_",x) for b in 1:39 for x in ("r","i")])) )
    CSV.write(joinpath(out,"native_terminal_current_pu.csv"),hcat(DataFrame(time_s=times),DataFrame(curr,[Symbol("BUS",b,"_",x) for b in pmus for x in ("r","i")])) )
    CSV.write(joinpath(out,"actual_load_power_pu.csv"),hcat(DataFrame(time_s=times),DataFrame(actual_load,[Symbol("BUS",b,"_",x) for b in loads for x in ("P","Q")])) )
    CSV.write(joinpath(out,"differential_states.csv"),hcat(DataFrame(time_s=times),DataFrame(dynamic,Symbol.("x".*string.(dyn)))))
    CSV.write(joinpath(out,"operator_line_current_pu.csv"),hcat(DataFrame(time_s=times),DataFrame(operator_current,[:src_r,:src_i,:dst_r,:dst_i])))
    CSV.write(joinpath(out,"all_operated_line_currents.csv"),hcat(DataFrame(time_s=times),DataFrame(all_operator_current,[Symbol("EDGE",e,"_",side,"_",part) for e in operated_edges for side in ("src","dst") for part in ("r","i")])))
    CSV.write(joinpath(out,"state_index.csv"),DataFrame(index=1:length(u0),symbol=string.(SII.variable_symbols(nw)),differential=mass.!=0))
    jumps=DataFrame(time_s=Float64[],max_differential_jump=Float64[],max_algebraic_jump=Float64[],post_algebraic_residual=Float64[],distance_from_initial_dynamic_state=Float64[])
    for t in updates
        left=event_before[t];right=sol.u[findlast(tt->abs(tt-t)<1e-9,sol.t)]
        nw(derivative,right,param_history[t],t)
        push!(jumps,(t,maximum(abs.(right[dyn].-left[dyn])),maximum(abs.(right[alg].-left[alg])),
            maximum(abs,derivative[alg]),maximum(abs.(right[dyn].-u0[dyn]))))
    end
    CSV.write(joinpath(out,"event_continuity.csv"),jumps)
    CSV.write(joinpath(out,"final_state.csv"),DataFrame(symbol=string.(SII.variable_symbols(nw)),value=sol.u[end]))
    CSV.write(joinpath(out,"solver_saved_times.csv"),DataFrame(internal_saved_time_s=sol.t))
    # These are diagnostic parameter histories, never inference observations.
    ph=DataFrame(time_s=Float64[],bus=Int[],Pset_pu=Float64[],Qset_pu=Float64[])
    for t in sort(collect(keys(param_history))),j in eachindex(loads)
        push!(ph,(t,loads[j],param_history[t][ip[j]],param_history[t][iq[j]]))
    end
    CSV.write(joinpath(out,"input_parameters_applied.csv"),ph)
    passed=maximum(jumps.max_differential_jump)<1e-9 && max_alg<1e-6 && allowed_delta==0.
    status=Dict("case"=>id,"retcode"=>string(sol.retcode),"duration_s"=>duration,"reports"=>length(times),
        "physical_initializations"=>1,"trajectory_solves"=>1,"dynamic_state_resets"=>0,
        "scheduled_updates"=>length(updates),"max_differential_jump"=>maximum(jumps.max_differential_jump),
        "max_algebraic_residual"=>max_alg,"non_input_parameter_change"=>allowed_delta,
        "frozen_initial_state_exact"=>case["operating_point"]=="F01","frozen_parameters_exact"=>case["operating_point"]=="F01",
        "operating_point"=>case["operating_point"],"structural_parameters_frozen"=>true,"elapsed_seconds"=>elapsed,
        "solver_diagnostic_saved_points"=>length(sol.t),"post_update_report_policy"=>true,
        "continuity_and_frozen_plant_pass"=>passed)
    jsonwrite(joinpath(out,"status.json"),status)
    @assert passed
    println("CASE_COMPLETE ",JSON.json(status));flush(stdout)
    return status
end

function initialize_operating_point(nw,sbase,op)
    name=op["id"];out=joinpath(ROOT,"operating_points",name);mkpath(out)
    # A different equilibrium may change dispatch/load/excitation setpoints,
    # never machine, regulator, line, voltage-base or ZIP-law constants.
    if name=="F01"
        s=NWState(nw,copy(uflat(sbase)),copy(pflat(sbase)),0.)
    else
        pfnw=powerflow_model(nw);pfs0=NWState(pfnw)
        targets=CSV.read(joinpath(REF,"target_bus_state.csv"),DataFrame)
        buses=CSV.read(joinpath(REF,"data/bus.csv"),DataFrame)
        for row in eachrow(buses)
            b=Int(row.bus);r=targets[targets.bus.==b,:][1,:]
            if row.bus_type=="PQ"
                pfs0.v[b].p[:pq₊P]=op["p_factor"]*r.p_injection_pu
                pfs0.v[b].p[:pq₊Q]=op["q_factor"]*r.q_injection_pu
            elseif row.bus_type=="PV"
                pfs0.v[b].p[:pv₊P]=op["dispatch_factor"]*r.p_injection_pu
                pfs0.v[b].p[:pv₊V]=r.vm_pu
            else
                pfs0.v[b].p[:slack₊V]=r.vm_pu
            end
        end
        pfs=solve_powerflow(nw;pfnw,pfs0,verbose=false)
        s=initialize_from_pf!(nw;pfs,verbose=false)
    end
    symbols=string.(SII.parameter_symbols(nw));delta=pflat(s).-pflat(sbase)
    allowed=findall(x->any(occursin(k,x) for k in (":ZIPLoad₊Pset",":ZIPLoad₊Qset","₊gov₊p_ref","₊avr₊vref",":machine₊vf_set",":machine₊τ_m_set")),symbols)
    fixed=setdiff(1:length(delta),allowed)
    @assert maximum(abs.(delta[fixed]))<1e-10
    du=zeros(length(uflat(s)));nw(du,uflat(s),pflat(s),0.)
    @assert maximum(abs,du)<1e-7
    CSV.write(joinpath(out,"initial_state.csv"),DataFrame(symbol=string.(SII.variable_symbols(nw)),value=uflat(s)))
    CSV.write(joinpath(out,"initial_parameters.csv"),DataFrame(symbol=symbols,value=pflat(s)))
    CSV.write(joinpath(out,"parameter_changes.csv"),DataFrame(symbol=symbols,before=pflat(sbase),after=pflat(s),difference=delta,operating_input=[i in allowed for i in eachindex(delta)]))
    voltage_get=SII.getsym(nw,[VIndex(b,Symbol("busbar₊u_",part)) for b in 1:39 for part in ("r","i")]);v=reshape(voltage_get(s),2,39);vabs=sqrt.(v[1,:].^2+v[2,:].^2)
    jsonwrite(joinpath(out,"status.json"),Dict("id"=>name,"equilibrium_residual"=>maximum(abs,du),"structural_parameter_max_change"=>maximum(abs.(delta[fixed])),"changed_operating_inputs"=>sum(abs.(delta).>1e-10),"voltage_min_pu"=>minimum(vabs),"voltage_max_pu"=>maximum(vabs),"state_initialization_only_once_per_trajectory"=>true))
    println("OP_VERIFIED ",name," residual=",maximum(abs,du));flush(stdout)
    return s
end

function op_main()
    BLAS.set_num_threads(1)
    cfg=JSON.parsefile(joinpath(ROOT,"events/protocol.json"));nw,sbase=initialize_frozen();statuses=[];ops=Dict()
    for op in cfg["operating_points"]
        try
            ops[op["id"]]=initialize_operating_point(nw,sbase,op)
        catch err
            out=joinpath(ROOT,"operating_points",op["id"]);mkpath(out)
            jsonwrite(joinpath(out,"REJECTED.json"),Dict("id"=>op["id"],"stage"=>"initialization","error"=>sprint(showerror,err)))
            println("OP_REJECTED ",op["id"]," ",sprint(showerror,err));flush(stdout)
        end
    end
    if "--init-only" in ARGS;return;end
    for case in cfg["cases"]
        id=case["id"];out=joinpath(ROOT,"events/diagnostics",id);mkpath(out)
        if isfile(joinpath(out,"status.json"));println("ALREADY_COMPLETE ",id);continue;end
        if !haskey(ops,case["operating_point"])
            jsonwrite(joinpath(out,"REJECTED.json"),Dict("case"=>id,"stage"=>"initialization","error"=>"Operating point rejected"));continue
        end
        cc=deepcopy(cfg);eds=[a["asset"] for a in case["actions"] if a["kind"]=="edge"];!isempty(eds) && (cc["line_edge_1based"]=first(eds))
        try
            push!(statuses,run_case(nw,ops[case["operating_point"]],cc,case))
        catch err
            jsonwrite(joinpath(out,"REJECTED.json"),Dict("case"=>id,"stage"=>"trajectory","error"=>sprint(showerror,err)));println("CASE_REJECTED ",id," ",sprint(showerror,err));flush(stdout)
        end
        jsonwrite(joinpath(ROOT,"events/results/campaign_status.json"),statuses);GC.gc()
    end
end
op_main()
