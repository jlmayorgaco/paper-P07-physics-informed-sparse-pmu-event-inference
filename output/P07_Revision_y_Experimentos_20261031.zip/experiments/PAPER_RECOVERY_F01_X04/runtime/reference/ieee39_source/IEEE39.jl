module IEEE39

using Graphs
using Random
using PowerDynamics
using PowerDynamics.Library
using ModelingToolkitBase
using ModelingToolkitBase: t_nounits as t
using SciCompDSL: @mtkmodel
using NetworkDynamics
using DataFrames
using CSV
using DiffEqCallbacks
using PrecompileTools
using SciMLBase

include("distributed_slack.jl")
export DistributedSlackLead, DistributedSlackFollow
export dist_slack_lead_current_source, dist_slack_follow_current_source

include("ieee39_base.jl")
export get_IEEE39_base, set_IEEE39_PF_init, get_MATPOWER_LineRatings_MVA, get_MATPOWER_LineRatings_pu
export load_ieee39_scenario, with_ieee39_bases

include("ieee39_random_pf.jl")
export generate_powerflow_variation, generate_gog_powerflow_variation

include("grid_of_grids.jl")
export build_IEEE39_grid_of_grids

include("utilities.jl")
export sc_and_trip, sc_and_trip_and_kill, sc_and_clear
export export_nodes_json, export_lines_json, import_network_from_json
export node_nf_linearization, nf_linearization

function pre()
    nw_base = get_IEEE39_base()
    nw = set_IEEE39_PF_init(nw_base)
    pfnw = powerflow_model(nw)
    pfs0 = NWState(pfnw)
    pfs_init = initialize_from_pf(nw; verbose=false);
end

@compile_workload pre()

end # module IEEE39
