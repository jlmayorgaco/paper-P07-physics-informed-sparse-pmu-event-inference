"""M02 conditional nonlinear-model evidence, not a physical-state EKF.

Only public model artifacts are read here. process() consumes one new report.
Joint source/amplitude/duration/onset histories induce dependence across the
sensor families, even though their F01 instrumental innovations are independent.
"""
from pathlib import Path
import json,time
import numpy as np
from scipy.linalg import block_diag,solve_discrete_lyapunov,solve_triangular
from scipy.special import logsumexp

FIELDS=['voltage_magnitude','voltage_angle','current_magnitude','current_angle','frequency','rocof']
ARMS={'VI':4,'VI_F':5,'VI_F_R':6}
def wrap(a):return (a+180)%360-180
def psd(a):
    a=np.array(a);v,u=np.linalg.eigh((a+a.T)/2);return (u*np.maximum(v,1e-12))@u.T

class ColoredInstrument:
    """Fixed-gain innovations filter from archived VAR/AR, normalized units."""
    def __init__(self,spec,keep):
        self.F=block_diag(np.array(spec['VAR1_transition']),np.diag(spec['PMU_local_AR1']))
        self.Q=block_diag(psd(spec['innovation_covariance']),psd(spec['PMU_local_innovation_covariance']))
        self.H=np.c_[np.array(spec['loadings']).T,np.eye(8)][keep]
        self.R=np.eye(len(keep))*1e-12
        stationary=solve_discrete_lyapunov(self.F,self.Q);P=stationary.copy();saved=None
        for k in range(10000):
            S=self.H@P@self.H.T+self.R;K=np.linalg.solve(S,self.H@P).T
            posterior=P-K@self.H@P
            nxt=self.F@posterior@self.F.T+self.Q;nxt=(nxt+nxt.T)/2
            if k==59:saved=nxt.copy()
            if np.max(abs(nxt-P))<1e-13 and k>=60:break
            P=nxt
        else:raise RuntimeError('Riccati did not converge')
        self.K=K;self.L=np.linalg.cholesky(S);self.W=solve_triangular(self.L,np.eye(len(keep)),lower=True)
        self.A=self.F@(np.eye(len(P))-self.K@self.H);self.B=self.F@self.K
        self.warmup_cov_relative_error=float(np.linalg.norm(saved-P)/np.linalg.norm(P))
        self.stationary_variance=np.diag(self.H@stationary@self.H.T)
        self.n=len(P);self.m=np.zeros(self.n)
    def process(self,y):
        e=y-self.H@self.m;z=self.W@e;self.m=self.A@self.m+self.B@y;return z
    def whiten(self,y):
        """Whiten a deterministic mean shift; zero shift state before onset."""
        m=np.zeros((y.shape[0],self.n));out=np.empty_like(y)
        for k in range(y.shape[1]):
            e=y[:,k]-m@self.H.T;out[:,k]=e@self.W.T;m=m@self.A.T+y[:,k]@self.B.T
        return out

class Model:
    def __init__(self,folder):
        self.folder=Path(folder);self.assets=json.loads((self.folder/'assets.json').read_text());self.design=json.loads((self.folder/'bank_design.json').read_text())
        self.cfg=json.loads((self.folder/'reporting_config.json').read_text());self.noise=json.loads((self.folder/'stochastic_model.json').read_text())
        self.keep=[np.arange(8),np.arange(8),np.arange(8),np.arange(7),np.arange(8),np.arange(8)]
        self.filters=[ColoredInstrument(self.noise['families'][f],keep) for f,keep in zip(FIELDS,self.keep)]
        self.centers=[np.array(self.noise['families'][f]['normalization_center'])[keep] for f,keep in zip(FIELDS,self.keep)]
        self.scales=[self.noise['families'][f]['normalization_scale'] for f in FIELDS]
        with np.load(self.folder/'deterministic/B000.npz') as z:
            self.base=[z[f][10,keep].copy() for f,keep in zip(FIELDS,self.keep)]
            for j in [1,3]:self.base[j]-=self.cfg['common_phase_slope_deg_s']*z['time_s'][10]
        self.ids=[d for d in self.design if d['source'] is not None]
        self.cell=np.array([next(i for i,a in enumerate(self.assets) if a['id']==d['source']) for d in self.ids])
        self.duration=np.array([np.inf if d['off_s'] is None else (d['off_s']-d['onset_s'])*30 for d in self.ids])
        self.amplitude=np.array([np.nan if d['amplitude'] is None else d['amplitude'] for d in self.ids])
        # Equal families, equal sources within family, equal holding nodes; proper discrete amplitude prior.
        p=[]
        for d in self.ids:
            amps=np.array([-.2,-.1,.1,.2]);ap=np.exp(-.5*(amps/.15)**2);ap/=ap.sum()
            p.append(.5/6/4*(ap[np.flatnonzero(amps==d['amplitude'])[0]] if d['family']=='load' else 1.))
        self.prior=np.array(p);assert abs(self.prior.sum()-1)<1e-12
        cache=self.folder/'whitened.npz'
        with np.load(cache) as z:
            self.signals=[z[f] for f in FIELDS]
        self.maxage=self.signals[0].shape[1]-1
        self.phase_lift={}
    def observation(self,t,report,fields):
        out=[]
        for j in range(fields):
            y=np.asarray(report[FIELDS[j]],float)[self.keep[j]]-self.centers[j]
            if j in [1,3]:
                y=wrap(y-self.base[j]-self.cfg['common_phase_slope_deg_s']*t)
                if j in self.phase_lift:y=self.phase_lift[j]+wrap(y-self.phase_lift[j])
                self.phase_lift[j]=y.copy()
            else:y-=self.base[j]
            if not np.all(np.isfinite(y)):
                # Only the four initial F/R warmup reports are permitted here.
                if t>4/30+1e-9:raise ValueError('Missing/invalid report outside supported startup mask')
                y=np.zeros_like(y)
            out.append(self.filters[j].process(y/self.scales[j]))
        return np.concatenate(out)

def build_dictionary(folder):
    folder=Path(folder);design=json.loads((folder/'bank_design.json').read_text());cfg=json.loads((folder/'reporting_config.json').read_text());noise=json.loads((folder/'stochastic_model.json').read_text())
    keep=[np.arange(8),np.arange(8),np.arange(8),np.arange(7),np.arange(8),np.arange(8)]
    with np.load(folder/'deterministic/B000.npz') as z:base={f:z[f] for f in FIELDS}
    sig={f:[] for f in FIELDS};warmups={}
    for d in design:
        if d['source'] is None:continue
        with np.load(folder/'deterministic'/(d['id']+'.npz')) as z:
            k=int(round(d['onset_s']*30))
            for j,f in enumerate(FIELDS):
                delta=z[f]-base[f]
                if j in [1,3]:delta=np.rad2deg(np.unwrap(np.deg2rad(wrap(delta)),axis=0))
                # Complete archived estimator history has already been processed before slicing.
                s=delta[k:,keep[j]]/noise['families'][f]['normalization_scale']
                assert np.all(np.isfinite(s));sig[f].append(s)
    out={}
    for j,f in enumerate(FIELDS):
        filt=ColoredInstrument(noise['families'][f],keep[j]);out[f]=filt.whiten(np.array(sig[f]))
        warmups[f]=filt.warmup_cov_relative_error
    np.savez_compressed(folder/'whitened.npz',**out)
    (folder/'WHITENER.json').write_text(json.dumps(dict(warmup_cov_relative_error=warmups,gaussian_clipping_approximation=True),indent=2))

class EpisodeTensor:
    def __init__(self,model,arm,protocol):
        self.model=model;self.fields=ARMS[arm];self.cfg=protocol;self.k=-1
        self.S=np.concatenate(model.signals[:self.fields],axis=2)
        self.energy=np.sum(self.S*self.S,axis=2)
        self.nt=len(model.ids);self.tc=np.empty(0,int);self.on=np.empty(0,int);self.w=np.empty(0)
        self.normal=1.;self.logn=0.;self.logw=np.empty(0);self.M=np.zeros(12);self.cause=np.zeros(12)
        self.confirm=0;self.alarm=None;self.birth=1-np.exp(-protocol['birth_hazard_per_s']/30)
        self.pruned_cumulative=0.;self.max_norm_error=0.;self.max_dM_error=0.
    def _project(self,w,active=None):
        if active is not None:w=w*active
        return np.bincount(self.model.cell[self.tc],weights=w,minlength=12)
    def process(self,t,report):
        begin=time.perf_counter();self.k+=1;k=self.k;assert abs(t-k/30)<1e-7
        z=self.model.observation(t,report,self.fields)
        if k<self.cfg['warmup_frames']:
            return dict(time_s=t,last_report_used_s=t,normal=1.,active=0.,cause=0.,alarm=False,first_alarm_s=np.nan,M=self.M.copy(),M_cause=self.cause.copy(),delta_M=np.zeros(12),delta_cause=np.zeros(12),activation=np.zeros(12),retirement=np.zeros(12),revision=np.zeros(12),discarded_mass=0.,onset_mean_s=np.nan,off_mean_s=np.nan,histories=0,runtime_s=time.perf_counter()-begin,nis=float(z@z),posterior_residual_per_dof=float(z@z)/len(z))
        prev=self.M.copy();oldcause=self.cause.copy();oldages=k-self.on
        off=(oldages>=self.model.duration[self.tc]) & (oldages-1<self.model.duration[self.tc])
        retirement=self._project(self.w*off)
        born=self.normal*self.birth*self.model.prior
        activation=np.bincount(self.model.cell,weights=born,minlength=12)
        logborn=self.logn+np.log(self.birth)+np.log(self.model.prior)
        self.logn+=np.log1p(-self.birth);self.normal=float(np.exp(self.logn))
        self.tc=np.r_[self.tc,np.arange(self.nt)];self.on=np.r_[self.on,np.full(self.nt,k)];self.w=np.r_[self.w,born]
        self.logw=np.r_[self.logw,logborn]
        age=k-self.on;active=age<self.model.duration[self.tc]
        # Predictive finite dictionary ends at 20 s. Retire expired hypotheses explicitly.
        valid=age<=self.model.maxage
        expired=float(self.w[~valid].sum());self.tc=self.tc[valid];self.on=self.on[valid];self.w=self.w[valid];self.logw=self.logw[valid];age=age[valid];active=active[valid]
        # Each NEW observation contributes one ratio. Rolling windows are not multiplied again.
        inc=np.einsum('ij,j->i',self.S[self.tc,age],z)-.5*self.energy[self.tc,age]
        self.logw+=inc
        norm=logsumexp(np.r_[self.logn,self.logw]);self.logn-=norm;self.logw-=norm
        self.w=np.exp(self.logw);self.normal=float(np.exp(self.logn))
        # Retain all onsets for ten seconds and the 256 largest older hypotheses.
        recent=age<=round(self.cfg['retrospective_s']*30)
        older=np.flatnonzero(~recent);keep=recent.copy()
        if len(older):keep[older[np.argsort(self.logw[older])[-256:]]]=True
        lost=float(self.w[~keep].sum());self.tc=self.tc[keep];self.on=self.on[keep];self.logw=self.logw[keep];active=active[keep]
        remaining=logsumexp(np.r_[self.logn,self.logw]);self.logn-=remaining;self.logw-=remaining
        self.normal=float(np.exp(self.logn));self.w=np.exp(self.logw)
        self.pruned_cumulative+=lost+expired
        self.M=self._project(self.w,active);self.cause=self._project(self.w)
        delta=self.M-prev;revision=self.M-(prev+activation-retirement)
        self.max_dM_error=max(self.max_dM_error,float(np.max(abs(delta-activation+retirement-revision))))
        self.max_norm_error=max(self.max_norm_error,abs(self.normal+self.cause.sum()-1))
        pa=self.M.sum();self.confirm=self.confirm+1 if pa>=self.cfg['alarm_probability'] else 0
        alarm=False
        if self.alarm is None and self.confirm>=self.cfg['confirmation_frames']:self.alarm=t;alarm=True
        if self.cause.sum()>0:
            om=float(self.w@self.on/self.w.sum()/30)
            off_t=self.on+self.model.duration[self.tc];finite=np.isfinite(off_t)
            fm=float(self.w[finite]@off_t[finite]/self.w[finite].sum()/30) if self.w[finite].sum()>1e-12 else np.nan
        else:om=fm=np.nan
        return dict(time_s=t,last_report_used_s=t,normal=self.normal,active=pa,cause=self.cause.sum(),alarm=alarm,first_alarm_s=self.alarm if self.alarm is not None else np.nan,M=self.M.copy(),M_cause=self.cause.copy(),delta_M=delta,delta_cause=self.cause-oldcause,activation=activation,retirement=retirement,revision=revision,discarded_mass=lost+expired,onset_mean_s=om,off_mean_s=fm,histories=len(self.w),runtime_s=time.perf_counter()-begin,nis=float(z@z),posterior_residual_per_dof=float((z@z-2*self.w@inc[keep])/len(z)))
