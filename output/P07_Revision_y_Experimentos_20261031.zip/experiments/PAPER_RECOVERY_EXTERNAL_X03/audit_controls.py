"""Independent algebra and archive audit. These are controls, not new theory."""
from pathlib import Path
import hashlib,json,sys
import numpy as np,pandas as pd
from scipy.linalg import expm
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[1]
def main():
    out=ROOT/'audit';out.mkdir(exist_ok=True)
    results=[]
    def check(name,error,tol):
        results.append(dict(name=name,error=float(error),tolerance=tol,passed=bool(error<tol)))
    # An additive LTI input response cannot depend on the starting state.
    A=np.array([[-.2,2.],[-2.,-.4]]);B=np.array([[1.],[.3]]);C=np.array([[1.,2.],[.5,-1.]])
    x=np.array([.4,-.3]);a=.01;aug=np.block([[A,B],[np.zeros((1,3))]])
    errors=[]
    for t in np.arange(46)/30:
        T=expm(aug*t);increment=C@(T[:2,2]*a)
        contrast=C@(T[:2,:2]@x+T[:2,2]*a)-C@(T[:2,:2]@x)
        errors.append(np.max(abs(increment-contrast)))
    check('LTI history does not change incremental signature',max(errors),1e-12)
    # Adding nuisance covariance cannot increase fixed-vector squared distance.
    rng=np.random.default_rng(391003);Q=rng.normal(size=(15,4));v=rng.normal(size=15)
    values=[float(v@np.linalg.solve(np.eye(15)+s*Q@Q.T,v)) for s in [0.,.1,1.,10.]]
    check('Fixed response loses precision as nuisance covariance increases',max(0.,max(np.diff(values))),1e-12)
    # Full frozen F01 network, static algebra only. No dynamic intervention claimed.
    ref=REPO/'SIM0001_JuliaPD_F01/runtime/reference';d=np.load(ref/'fixed_network.npz');Y=d['Ybus'];Yf=d['Yf'];Yt=d['Yt']
    mapping=pd.read_csv(ref/'terminal_mapping.csv');v=pd.read_csv(ref/'target_bus_state.csv');V=v.u_r.to_numpy()+1j*v.u_i.to_numpy()
    rows=[]
    for e in range(len(Yf)):
        ids=np.flatnonzero(abs(Yf[e])+abs(Yt[e])>1e-14);assert len(ids)==2
        # Identify source/destination from branch metadata (never guess by row order).
        branch=pd.read_csv(ref/'data/branch.csv').iloc[e]
        f=int(branch['src_bus'])-1
        t=int(branch['dst_bus'])-1
        stamp=np.zeros_like(Y);stamp[f]=Yf[e];stamp[t]=Yt[e]
        Iopen=(Y-stamp)@V;Iequiv=Iopen+stamp@V
        err=float(np.max(abs(Y@V-Iequiv)))
        observed=[int(r.pmu_bus) for r in mapping.itertuples() if int(r.edge)==e]
        diffs=[]
        for r in mapping.itertuples():
            current=(Yf if r.side=='src' else Yt)[int(r.edge)]@V
            diffs.append(abs(current) if int(r.edge)==e else 0.)
        rows.append(dict(edge_zero_based=e,src=f+1,dst=t+1,kcl_equivalence_error=err,
                         pmu_current_operator_changes=bool(observed),observed_by=','.join(map(str,observed)),max_current_difference_pu=max(diffs)))
    pd.DataFrame(rows).to_csv(out/'F01_STATIC_LINE_INJECTION_EQUIVALENCE.csv',index=False)
    check('Line removal equals arbitrary endpoint current injections at fixed voltage',max(r['kcl_equivalence_error'] for r in rows),1e-10)
    # This identity does not mean a constant P/Q pulse or generator can realize Iequiv(t).
    pd.DataFrame(results).to_csv(out/'CONTROLS.csv',index=False)
    assert all(r['passed'] for r in results)
    (out/'SUMMARY.json').write_text(json.dumps(dict(controls=results,branches=len(rows),direct_current_discriminants=sum(r['pmu_current_operator_changes'] for r in rows),
      scope='Static identity at frozen voltage, not a feasible steady state after every opening; no full dynamic line simulation',
      consequence='Equivalent endpoint injections are generally voltage/time dependent. Unmeasured branch identity does not imply dynamic unidentifiability.',
      protected_input_hashes={str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ref/'fixed_network.npz',ref/'terminal_mapping.csv',ref/'target_bus_state.csv']}),indent=2))
    print(json.dumps(results))
if __name__=='__main__':main()
