# Ejecución obligatoria en el repositorio SGSMA26-Physics-Informed-AD

**Este documento es una instrucción técnica, no evidencia de que el análisis completo ya ocurrió.** Preparado el 31 de octubre de 2026.

## Misión científica

Determinar si la respuesta incremental de una fuente débil condicionada por el estado de recuperación contribuye a (a) identificar la fuente entre competidores casi colineales, (b) recuperar cardinalidad de dos fuentes, o (c) reducir el cómputo de la inferencia física. Los resultados de `PMU_Recovery_Identifiability_Pilot` son un control en una DAE clásica simplificada y NO justifican ninguna reivindicación en IEEE Access. La implementación definitiva debe utilizar la planta original F01 de PowerDynamics con máquinas Sauer-Pai de sexto orden, AVR Type I, TGOV1, cargas ZIP y los 47 canales declarados por R11.

## Fase 0 — Integridad y fuente de verdad (obligatoria)

1. Abrir el repositorio correcto; registrar `git status`, `git rev-parse HEAD`, rama, estado sucio, versiones Julia/PowerDynamics y hardware.
2. Buscar `R11`, `H04`, `C01`, `global_137_confirmatory_v1`, `load_tangent_v2`, generadores F01, mapeos de CT terminal y PMU filter/ROCOF. Registrar rutas concretas, SHA256 de insumos y resultados congelados.
3. Reproducir R11 H04 y revisar el estado *real* de C01. **Nunca abrir la verdad confirmatoria para ajustar método ni reescribir las cifras previas**. Si C01 fue usada en desarrollo, definir otro TEST independiente.
4. Verificar las 47 coordenadas exactas, los ocho buses PMU y los nueve buses/nueve líneas del catálogo R11; no confundirlo con el catálogo EB GLOBAL-137 de 137 soportes.
5. Auditar la implementación real de callbacks ON/OFF: continuidad de x, consistencia algebraica, estado antes/después de conmutación, terminal de BUS5 y ángulo de corriente BUS39 excluido. El código histórico aparentemente cambia parámetros sin reinicializar z: resolver cualquier diferencia entre el callback y la hipótesis editorial de salto algebraico antes de generar experimentos.

## Fase 1 — Comparador físico exacto sin usar información futura

Generar trayectorias pares que comparten exactamente el prefijo hasta el instante τ de intervención secundaria: `h` (solo recuperación) y `h⊕s` (nueva intervención). No reutilizar el verdadero x_τ en inferencia operacional; el fork con x verdadero es SOLO un test de consistencia física. El estimador real recibe el posterior causal del estado antes de τ, obtenido de los PMU.

Congelar previamente:
- Dos o más fuentes previas; no seleccionar después de abrir TEST.
- Tres o más parejas débiles de carga que compartan una fuente, incluidas las del banco GLOBAL-137 identificadas sobre TRAIN/DEV.
- Dos o más escenarios de línea abiertos/reconectados en el catálogo R11.
- Retardos relativos a OFF, incluyendo 0, 0.25, 0.5, 1, 2, 4 s y condiciones fuera de estos puntos; horizonte primario 0.3,1.0,1.5s.
- Condiciones de red nominales, R/X dentro del banco, fuera del banco, variaciones de operación y escalas de ruido; parent IDs y semillas independientes.

No reutilizar C01 confirmatoria para seleccionar pares/severidades/tiempos.

## Fase 2 — Operador DAE nodo-rama de alta fidelidad

Para cada modo q de la DAE xdot=f_q(x,z,a,θ), 0=g_q(x,z,a,θ), y=h_q(x,z,θ), implementar soluciones de sistemas dispersos con el Jacobiano algebraico J=g_z:

```
A = f_x - f_z * solve(J,g_x)
B_s = f_a_s - f_z * solve(J,g_a_s)
C = h_x - h_z * solve(J,g_x)
D_s = h_a_s - h_z * solve(J,g_a_s)
```

Cada fuente nodal s tiene una tangente forzada `S'_s=A(t)S_s+B_s(t)` desde el estado previo de su historia; `G_s=C(t)S_s+D_s`. El operador de corriente terminal debe usar la primitiva de rama, tap, charging y orientación, no confundirla con corriente de inyección en bus. Frecuencia y ROCOF deben derivarse de la transformación instrumental causal, no sustituirse por velocidad de rotor.

Para eventos de línea, usar un verdadero cambio de modo de la red (q, topología y terminales) en el contrafactual. NO extrapolar una derivada de load a una apertura completa de línea. Incluir saltos en z, estados instrumentales y sensibilidades híbridas solo según el callback que realmente usa F01. Conservar x continuo cuando la planta lo prescriba.

Validación matemática obligatoria:
- Comparar derivadas desde la DAE contra diferencias finitas de TDS completas con escalas h, h/2, h/4, verificando convergencia y signo.
- No confundir la validación AC estática de este paquete con la validación DAE; en estudios previos existía una discrepancia 2–6% de segundo orden entre tangentes y TDS que requiere investigación independiente.
- Verificar predicción para onsets antes/después de OFF, con perturbaciones de amplitud suficientemente pequeña y luego operativas.
- Reportar error por canal y hora, además de norma global, y costo CPU comparado con rollouts exactos.

## Fase 3 — Separabilidad bajo nuisance, no solo distancia euclidiana

Para fuente real i con severidad conocida de la planta de evaluación pero oculta al estimador, y competidor j, definir el contraste físico como la distancia en mediciones blancas con amplitudes del competidor y parámetros de molestia **perfilados/marginalizados de manera físicamente admisible**. Evitar la degeneración de cero fuentes. Comparar el signo de:

`Delta_d2(Δ) = d2(recovery,Δ) - d2(equilibrium)`.

Esta medida NO es exact-support probability. Calcular al menos:
- d² con historia/estado conocido (oracle, solo diagnóstico geométrico).
- d² con posterior causal sobre estado y parámetros (operacional).
- d² para modelo aditivo versus término de interacción físico condicionado, manteniendo igual sensor/ruido.
- Error de perfilado para pares que comparten fuente; event cardinality K=1 versus K=2.
- Matrices de covarianza de PMU temporalmente correlacionadas, covarianza entre frecuencia/ROCOF/fase, y máscaras de canales perdidos.

El piloto reducido detectó **NO aumento general** de separabilidad con incertidumbre: mediana ratio 0.92 para 36 escenarios dependientes y solo 1/36>1. Intentar refutar esta observación sobre F01, no presuponer su signo.

## Fase 4 — Inferencia bayesiana operativa

Crear cuatro variantes con exactamente la misma física y datos:

A. R11 completo congelado, sin modificaciones.
B. R11 con *new-event* firmas de equilibrio congeladas, para identificar específicamente sesgo de modelos no condicionados (solo control de ablación, NO pretendido SOTA).
C. R11 con operadores condicionados y marginalización causal de x, parámetros y severidad, estado previo estimado por PMU, no oráculo.
D. IMM/M3H adaptado correctamente a los mismos modos eléctricos, historias ON/OFF y sensores; comparar evidencia, costo y decisiones. En subproblema pertinente, incluir Group LASSO y EB GLOBAL-137.

H0 debe estar explícito. Evaluar detección, localización, cardinalidad, onset, OFF, alarmas por exposición, tiempo antes de OFF, log-loss/Brier bajo un generador cuyo prior corresponda al declarado, cobertura y mediana/p99 de latencia end-to-end. Mantener trayectoria física parental como unidad de independencia.

No confundir los 300 draws de ruido de este piloto con nuevas trayectorias físicas. No utilizar test labels para selección de soporte, onset, amplitud, diccionario o umbrales. Publicar todos los fallos y tiempos censurados.

## Fase 5 — Diseño de algoritmo nuevo si existe un hueco real

Solo si la fase 4 demuestra una ganancia física real, proponer un algoritmo de inferencia con:
- búsqueda de soporte disperso en nodos y aristas no instrumentados;
- historia ON/OFF, composición múltiple y recovery-only como hipótesis nula;
- propuestas rápidas desde Jacobiano DAE/grafo y refinamiento completo solo cuando las hipótesis sean competitivas;
- marginalización del estado previo, severidad y parámetros físicos;
- control explícito del error de aproximación de evidencia **si se puede certificar**, de lo contrario solo diagnosticarlo numéricamente.

**Ninguna de esas herramientas es novedosa por sí misma**. La posible contribución sería una operación concreta que produzca ventaja sobre R11 y M3H con la misma física, no la suma de conceptos.

## Fase 6 — Condiciones de circulación a Masoud Barati

Antes de afirmar novedad: citar los comparadores M3H/IMM, Group LASSO, identificación secuencial de líneas y estudios DAE de estados/entradas; reproducir nuestro baseline R11 en la campaña independiente. Una mejora de ajuste de señal no prueba mejora de fuente. Prohibido el lenguaje 'optimal', 'first', 'certified', 'novel physics-informed framework' sin el correspondiente teorema, evidencia y limitaciones.

Generar un reporte de revisor adversarial con (1) un aporte técnico realmente diferenciable; (2) algoritmo con pseudocódigo y costo; (3) comparación homóloga; (4) intervalos por padres físicos; (5) lista de resultados negativos; (6) gráfica evidencia/diagnóstico por tiempo; (7) decisión GO/NO GO. Si falta un dato, reportar ruta de exportación y bloqueo. No sustituir PowerDynamics por un proxy estático o este piloto reducido. Trabajar en una nueva rama; no hacer push ni modificar resultados congelados.

## Entregables del agente

```
research/recovery_conditioned_v1/
  README.md
  physics_model_audit.json
  code/                 # wrapper real DAE, Jacobianos, pruebas
  tests/                # física, FD, PMU, causalidad, evidencia
  data/                 # parent IDs + hashes + configuración
  results/              # por escenario con fallos/censuras incluidos
  figures/              # separabilidad, comparadores, ablaciones, costo
  reports/              # auditoría, conclusiones, manuscript readiness
```

## Mensaje listo para pegar en Codex

> En el repositorio SGSMA26-Physics-Informed-AD, lee `docs/CODEX_PORT_FULL_DAE.md` y el paquete experimental adjunto. Tu tarea no es escribir un nuevo paper primero: ejecuta las fases 0–4 con la DAE PowerDynamics F01 original, contrastando los resultados negativos/positivos de este piloto y preservando R11/C01 congelados. Si aparece una ventaja sobre M3H/R11 con contrato justo, desarrolla la fase 5; si no, redacta el NO-GO y los límites. No inventes un resultado para mejorar el paper, no confundas pruebas AC estáticas con la planta dinámica ni hagas push.
