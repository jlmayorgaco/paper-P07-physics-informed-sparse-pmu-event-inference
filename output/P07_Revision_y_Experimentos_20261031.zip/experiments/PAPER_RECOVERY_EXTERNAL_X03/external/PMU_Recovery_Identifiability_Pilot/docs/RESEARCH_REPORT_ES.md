# Auditoría experimental: ¿la recuperación electromecánica proporciona información diagnóstica nueva?

**Fecha:** 31 de octubre de 2026. **Estado:** exploratorio, resultado de un banco dinámico reducido. Este documento NO modifica el paper original ni sustituye la confirmación C01.

## 1. Hipótesis que intentamos refutar

Hipótesis candidata H*: la recuperación de una primera perturbación cambia las sensibilidades físicas de nuevas fuentes y aumenta su separación observable a través de ocho PMU dispersas. Si ello sucede, un modelo bayesiano condicionado por la historia podría identificar mejor una segunda fuente débil.

No se presupone H*. En sistemas lineales invariantes con entradas aditivas, las firmas incrementales son independientes de la historia y H* es falsa. En sistemas no lineales, puede aumentar o disminuir la separación; una historia incierta introduce además parámetros de molestia.

La versión actual de R11 conserva estados condicionados, predictores conmutados y explicación de recuperación. Por tanto, la mera dependencia de estado NO constituye una contribución nueva. La novedad exigirá demostrar una operación adicional o una ventaja rigurosa contra R11 e IMM/M3H con idéntica física.

## 2. Modelo físico que sí ejecutamos

Construimos una planta de prueba inspirada en el IEEE-39 público de MATPOWER. Usa las 46 ramas AC, incluidas resistencias, reactancias, taps y carga capacitiva. Las 39 tensiones algebraicas obedecen Kirchhoff. Hay diez máquinas clásicas con tensión interna de módulo fijo E' detrás de Xd'=0.25 pu. Sus estados son δ_i, Δω_i:

- δ_dot_i = ω_b Δω_i, con ω_b = 2π·60 rad/s.
- 2H_i Δω_dot_i = P_m,i − P_e,i − D_i Δω_i.
- S_G,i se calcula del flujo AC equilibrado original.
- Las cargas se convierten a admitancias Z constantes: y_L,i = conjugate(S_L,i) / |V_i,0|².
- La ecuación algebraica es `[Y_bus(q) + diag(y_L(1+a)) + diag_G(1/jX'_d)] V = I_Norton(δ)`.

Los H_i, amortiguamientos y Xd' son parámetros ilustrativos, NO los parámetros del PowerDynamics original. No implementamos máquinas Sauer–Pai, AVR, TGOV1 ni el resto del ZIP. Tampoco la frecuencia/ROCOF estimadas en PMU; se miden 32 coordenadas reales de 8 tensiones y 8 corrientes terminales bajo un mapa ilustrativo. Esto constituye un **modelo DAE clásico reducido**, no la planta F01/R11.

### Controles físicos

- Error máximo de reconstrucción del voltaje AC equilibrado: 5.37e-15 pu.
- Residuo inicial de KCL: 2.29e-13 pu.
- Residuo de swing en equilibrio: 1.24e-15.
- Sin perturbación, la trayectoria permanece en equilibrio dentro de la tolerancia del solver.
- Restaurar una carga preserva los estados de rotor; el equilibrio algebraico se recalcula con la nueva admitancia.

## 3. El nuevo operador fuente → PMU, calculado desde la DAE

Sea x=(δ,ω), V(x,a)=K(a)^(-1) I_Norton(δ), y=h(V). Para una fuente de carga s que nace en τ, la sensibilidad de estado cumple:

`d S_s(t)/dt = A(t) S_s(t) + B_s(t), S_s(τ)=0`.

`G_s(t;h) = C(t) S_s(t) + D_s(t)`.

Se derivan los términos del grafo, no mediante regresión:

- `∂V/∂δ_j = solve(K, e_Gj · (1/jXd_j) · i E'_j)`;
- `∂V/∂a_s = -solve(K, e_s · y_L,s · V_s)`;
- `∂P_e/∂δ_j` y `∂P_e/∂a_s` se obtienen diferenciando `Re(E'_i conjugate(I_G,i))`;
- la matriz A usa derivadas de P_e y el amortiguamiento swing;
- C,D usan el operador eléctrico de tensión/corriente **terminal**.

`src/tangent39.py` integra de manera conjunta trayectoria y sensibilidades para múltiples fuentes; usa factorización LU sobre la matriz algebraica de Kirchhoff. Se verificó contra diferencias finitas de trayectorias físicas independientes con tres buses fuente en equilibrio y recuperación. El error relativo fue 3.5e-9 a 1.7e-8. Es una validación del código **de este modelo reducido**; las sensibilidades y métodos tangentes son conocidos en la literatura.

La implementación Python actual NO muestra una aceleración robusta frente a seis rollouts: el beneficio de costo deberá probarse después de optimizar el operador o aumentar el catálogo.

## 4. Contrafactuales en una misma historia

Una intervención anterior en bus 7 o 24 comienza a t=0.2 s con severidad 8% de la carga y termina en t=1.0 s. Se calcula el estado físico de recuperación x_h(τ) a τ=1.0+Δ, con Δ∈{0,0.25,0.5,1,2,4} s. Desde **exactamente el mismo estado** se simulan recuperación sin nuevo evento y recuperación con nueva carga s:

`Δy_(s|h)(t) = Ψ(h⊕s)(t) − Ψ(h)(t)`.

Esto evita atribuir a una fuente una diferencia de estado inicial. Se comparan tres pares congelados antes de ejecutar el test: (18,27), (16,21) y (3,21), con severidad muy débil 0.06% de la carga de cada bus (a=0.0006). Los horizontes desde el onset secundario son 0.3, 1.0 y 1.5 s. Hay 2×6×3×3=108 configuraciones correlacionadas. El onset y los dos candidatos son conocidos: no hay detección continua, ni hipótesis H0, ni evento de línea en esta prueba.

## 5. Separación física bajo incertidumbre de la recuperación

Para hipótesis de fuente i y j, se aproxima la distancia del efecto de i contra una amplitud β de j (β>=0):

`d²_ij(h)=min_{β>=0} ||a_true·G_i(h)−β·G_j(h)||²_{Ω_h^{-1}}`.

Se calcula en ambas direcciones y se reporta el mínimo. La covarianza incorpora ruido coloreado AR(1) de ρ=0.85; una amplitud incierta del primer evento (std 0.01 en fracción de carga), y un offset angular común incierto (std 0.003 rad), mediante marginalización de bajo rango. No se incluyen todas las incertidumbres reales del estado de 20 dimensiones ni la de parámetros de la red.

**Resultado (1.5 s, 36 casos):** mediana `d²_recovery_uncertain/d²_equilibrium = 0.9199`. Solo **1 de 36** supera la unidad. Si omitimos incertidumbre sobre la primera severidad, la mediana es ~0.9998 y **18/36** casos superan la unidad. Por tanto, el beneficio de separabilidad no es sistemático ni robusto frente a la incertidumbre de historia representada.

Esto **rechaza como narrativa universal** que el transitorio de recuperación sea automáticamente una excitación natural que aumenta la localización. No descarta que existan casos físicos particulares o plantas detalladas donde ayude.

## 6. Inferencia bayesiana de fuente: control congelado vs condicionado

El ensayo restringido supone que ocurrió exactamente uno de los dos eventos en el instante conocido. La evidencia integra una amplitud gaussiana firmada a~N(0,0.0015²):

`log BF_s = 0.5·[σ_a² z_s²/(1+σ_a² I_s) − log(1+σ_a² I_s)]`,

`I_s=G_s^T Ω_h^(-1)G_s; z_s=G_s^T Ω_h^(-1)r`.

La fórmula es estadística clásica: la novedad no reside en el factor de Bayes. Los dos métodos reciben exactamente los mismos residuos, ruido, historia y prior; difieren solo en `G_s(equilibrium)` vs `G_s(recovery)`. Para cada fuente verdadera y configuración se generan 300 réplicas de ruido AR1 y molestia; 600 observaciones sintéticas por configuración. Estas réplicas no son nuevas plantas físicas. Las réplicas de ruido se reutilizan para comparar las dos variantes.

| Horizonte | Equilibrio coincidido | Firmas congeladas en recuperación | Firmas condicionadas en recuperación |
|---|---:|---:|---:|
| 0.3 s | 56.54% | 56.13% | 56.09% |
| 1.0 s | 66.75% | 62.61% | 65.81% |
| 1.5 s | **72.40%** | **67.14%** | **71.51%** |

Diferencia media pareada a 1.5 s: **+4.37 puntos porcentuales**, pero hay seis grupos físicos (par de fuentes × primer bus), con seis retrasos correlacionados por grupo. El intervalo exploratorio de 95% por bootstrap de esos seis grupos es **[-0.73, +9.14] puntos porcentuales**, incluye cero. En la pareja BUS18/BUS27, el condicionamiento **reduce** la exactitud para ambos primeros buses. No hay victoria general ni un nuevo récord IEEE-39.

## 7. La estructura de sensores y el ruido importan

Ablación **solo** para (18,27), previa BUS7, Δ=0.25 s, horizonte 1.5 s, ρ=0.85:

| Canales | Distancia cuadrática perfilada |
|---|---:|
| Solo voltajes rectangulares de 8 buses | 0.024 |
| Solo corrientes terminales orientadas | 0.122 |
| Voltajes + corrientes | 0.148 |

Esto ilustra que el operador de corrientes de **ramas reales** puede ser más discriminante que mirar únicamente voltajes, aunque el terminal usado en el prototipo es ilustrativo y no el productor de RAW0001.

Para los cuatro casos de ablación, elevar la correlación temporal asumida de ρ=0 a 0.95 reduce sustancialmente la distancia. La densidad temporal de muestras no equivale a 30 observaciones independientes por segundo. Resultados en `sensor_noise_nuisance_ablations.csv`.

## 8. Comparación adversarial contra lo que ya teníamos

El manuscrito R11 YA empieza los predictores desde estados físicos anteriores, conserva historias, integra severidad, compara predicciones y mantiene causas después de OFF. Por tanto:

- NO es novedoso decir solamente que las firmas dependen de la recuperación: ya puede estar parcialmente implementado en R11.
- NO es novedoso derivar A,B,C,D desde la DAE, diferenciar Kirchhoff, construir una integral gaussiana o usar Bayes.
- El **operador analítico para múltiples fuentes** es un artefacto verificable, pero todavía no mejoró demostrablemente ni costo ni exactitud frente a un M3H completo.
- Nuestro control `frozen signatures` es útil para aislar condicionamiento, **pero no es un competidor equivalente al R11 ni al M3H**, los cuales también pueden condicionar el estado.
- El experimento es un piloto, no un resultado que justifique reclamar un nuevo método en IEEE Access.

## 9. La oportunidad real y la prueba de abandono

Una dirección que todavía merece validarse con PowerDynamics es **la recuperación de múltiples entradas débiles y eventos híbridos nodo-rama mediante un operador físico condicional y una marginalización correcta de estado y parámetros**, junto con búsqueda selectiva de soportes. Esa formulación requiere: (i) derivar el operador de la DAE de sexto orden y medición PMU completa; (ii) reconstruir causalmente el estado y su covarianza desde el prefijo; (iii) estimar al menos 2 fuentes, tiempos desconocidos y recuperación; (iv) comparar con R11 congelado e IMM/M3H que comparta física y mediciones; (v) evaluar en poblaciones físicas independientes; (vi) demostrar una ventaja de decisión o de complejidad no disponible en el método anterior.

**Go/no-go:** si el operador condicional no supera R11/M3H en exactitud/calibración o costo para igual contrato, no convertir esto en la contribución principal. Si la mayor parte de la supuesta ventaja desaparece al marginalizar el estado previo, debemos presentar ese límite y buscar otro problema, no cambiar el nombre del algoritmo.

## 10. Fuentes y alcance

Ecuaciones swing, modelo clásico y reducción eléctrica: literatura de estabilidad de sistemas eléctricos; el código del modelo simplificado usa `ac39.py` transcrito del MATPOWER `case39.m`. El paper **actual** del usuario de 15 páginas es *Recovery-Aware Physical Event Attribution From Sparse PMUs*, cuyo R11 es mucho más detallado que este piloto. Como antecedentes de metodología: IMM (Blom y Bar-Shalom), M3H (Boers y Driessen), Group LASSO para entradas desconocidas (Anguluri, Kosut y Sankar) y estimación recursiva DAE (Katanic y colaboradores). Este estudio **no** establece prioridad científica mundial, resultados RAW0001, C01, all-family SGSMA, seis orden, AVR/TGOV1, ni operación en tiempo real.
