# IEEE39 recovery-conditioned source identifiability: controlled dynamic pilot

**Status (2026-10-31): exploratory, executable, NOT an IEEE Access validation.**

This package tests whether electromechanical recovery improves or degrades the
identifiability of a subsequent weak load event and whether conditioning each
source's physical response on the recovery state helps Bayesian diagnosis.

## Model and observational contract

- **Physical plant**: MATPOWER IEEE-39 AC graph (46 modeled branches, taps and charging), 39 algebraic bus voltages from Kirchhoff's current law, 10 classical synchronous machines represented by E' behind Xd' and swing equations, and constant-impedance loads.
- **Not present**: the original PowerDynamics SGSMA Sauer-Pai six-order machines, AVR Type I, TGOV1, detailed ZIP loads, actual PMU frequency/ROCOF estimator, original 47-channel R11 sensor/CT conventions, original GLOBAL-137 raw trajectories, and original H04/C01 baselines.
- **Measurements used**: 8 PMU buses `{2,5,6,10,19,22,29,39}`, each with rectangular bus voltage and an illustrative oriented branch-terminal current (32 real coordinates). **The terminal map is not producer-certified.**
- **Known onset and prior**: previous load occurs at 0.2 s, restores at 1 s, and a second source is compared at delays 0,0.25,0.5,1,2,4 seconds. The simulator supplies the true physical state at each fork (an oracle). The second-onset time and source pair are supplied to inference. This is **not** a causal detection/localization benchmark.
- **Noise**: assumed Gaussian AR(1) temporal correlation 0.85, V sigma 2e-4 and terminal current sigma 1e-3 per rectangular component, previous-load severity std 0.01 and common phase offset std 0.003 rad. These are experimental assumptions, not identified production PMU parameters.

## Run

```bash
python -m pip install numpy scipy pandas matplotlib
python src/run_pilot.py
python src/tangent39.py
python src/ablate_sensors_and_uncertainty.py
python src/benchmark_tangent.py
python src/plot_results.py
```

Start at repository root; outputs appear in `results/` and `figures/`.

## Main finding (1.5 s horizon, 36 correlated source-pair/history/delay cases)

| Condition | Mean 2-choice accuracy |
|---|---:|
| No previous disturbance, matched equilibrium signatures | 72.40% |
| Recovery data scored with frozen equilibrium signatures | 67.14% |
| Identical recovery data scored with conditioned signatures | 71.51% |

- Mean paired difference conditioned minus frozen: +4.37 percentage points **in this simulator only**.
- Six-group hierarchical-bootstrap descriptive 95% interval: -0.73 to +9.14 percentage points; includes zero. Groups comprise two previous load buses x three source pairs. Repeated delays and noise seeds are *not* independent physical plants.
- For source pair BUS18/BUS27, the conditioned model is worse for both previous-load buses; not a universal improvement.
- Median ratio of nuisance-profiled information under recovery to equilibrium: **0.920**; only 1/36 cases above 1. The claim that recovery naturally improves identifiability is **not supported** here.
- Analytic source-to-PMU Jacobian from KCL+time-varying swing tangents matches independent FD to relative error ~3.5e-9 to 1.7e-8 at equilibrium and recovery. This validates the *reduced* analytic operator.
- The Python tangent implementation shows no stable computational speedup against six nonlinear FD rollouts (see `runtime_tangent_vs_fd.json`).

## Files

- `src/ac39.py` - archived MATPOWER case39 AC input, from the previous independently verified package.
- `src/swing39.py` - network-preserving simplified classical DAE (Kirchhoff + swing).
- `src/tangent39.py` - analytic DAE source-to-PMU tangents for multiple sources.
- `src/run_pilot.py` - physical fork, source contrasts, Bayesian evidence, noise experiments.
- `src/ablate_sensors_and_uncertainty.py` - channel/AR1/history-uncertainty checks.
- `src/benchmark_tangent.py` - explicit runtime controls.
- `src/plot_results.py` - all summary figures.
- `results/` - raw per-case CSVs, numerical checks and manifests.
- `docs/RESEARCH_REPORT_ES.md` - full analysis, derivations and adversarial verdict.
- `docs/CODEX_PORT_FULL_DAE.md` - exact execution plan to validate with original PowerDynamics/R11 and publication gates.

The current result is **research triage**, not a validated new algorithm. In particular, R11 may already condition local predictors on retained states. A mere change of representation does not imply novelty.
