"""Publication-audit figures for the standalone reduced-swing pilot.
No cherry-picked figure hides negative scenarios. Use original scenario grouping.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent.parent
F=ROOT/'figures';F.mkdir(exist_ok=True)
d=pd.read_csv(ROOT/'results'/'per_case.csv')
d15=d[d.horizon_s==1.5].copy()
a=pd.read_csv(ROOT/'results'/'sensor_noise_nuisance_ablations.csv')

# 1: info geometry vs delay, medians across 2 priors*3 pairs
fig,ax=plt.subplots(figsize=(7.5,4.2))
g=d15.groupby('delay_s').agg(ideal=('information_ratio_ideal','median'),uncertain=('information_ratio_uncertain','median')).reset_index()
ax.plot(g.delay_s,g.ideal,'o-',label='Recovery, state assumed known')
ax.plot(g.delay_s,g.uncertain,'s-',label='Recovery, previous-event uncertainty')
ax.axhline(1,ls='--',lw=1,label='Equilibrium reference')
ax.set(xlabel='Delay after previous OFF (s)',ylabel='Profiled separation / equilibrium',title='No systematic information gain from recovery')
ax.legend(loc='best',fontsize=8);ax.grid(alpha=.25)
fig.tight_layout();fig.savefig(F/'information_vs_delay.png',dpi=210);fig.savefig(F/'information_vs_delay.pdf');plt.close(fig)

# 2: accuracy conditioned vs frozen and same equilibrium baseline
fig,ax=plt.subplots(figsize=(7.5,4.2))
g=d15.groupby('delay_s').agg(eq=('accuracy_equilibrium','mean'),frozen=('accuracy_frozen_during_recovery','mean'),conditional=('accuracy_conditioned_during_recovery','mean')).reset_index()
ax.plot(g.delay_s,100*g['eq'],'o--',label='Equilibrium data and signatures')
ax.plot(g.delay_s,100*g.frozen,'s-',label='Recovery with frozen signatures')
ax.plot(g.delay_s,100*g.conditional,'^-',label='Recovery with conditioned signatures')
ax.set(xlabel='Delay after previous OFF (s)',ylabel='Two-source choice accuracy (%)',title='Conditioning mitigates modeling bias, not always')
ax.set_ylim(50,90);ax.legend(loc='best',fontsize=8);ax.grid(alpha=.25)
fig.tight_layout();fig.savefig(F/'pair_accuracy_vs_delay.png',dpi=210);fig.savefig(F/'pair_accuracy_vs_delay.pdf');plt.close(fig)

# 3: all 6 prechosen physical groups, each point mean gain across 6 delays
fig,ax=plt.subplots(figsize=(7.5,4.0))
g=d15.groupby(['prior_bus','source_a','source_b'],as_index=False)['paired_accuracy_gain'].mean()
labels=[f'Previous {int(x.prior_bus)}, pair {int(x.source_a)}/{int(x.source_b)}' for x in g.itertuples()]
xx=np.arange(len(g));ax.bar(xx,100*g.paired_accuracy_gain)
ax.axhline(0,ls='--',lw=1)
ax.set_xticks(xx,labels,rotation=27,ha='right',fontsize=8)
ax.set(ylabel='Conditioned minus frozen accuracy (pp)',title='Failure cases remain visible (six physical groups)')
ax.grid(axis='y',alpha=.25);fig.tight_layout()
fig.savefig(F/'paired_accuracy_by_physical_group.png',dpi=210);fig.savefig(F/'paired_accuracy_by_physical_group.pdf');plt.close(fig)

# 4: all group info ratios as heatmap with colorbar; fixed scale no cherry picking
fig,ax=plt.subplots(figsize=(7.5,4.0))
g=d15.pivot_table(index=['prior_bus','source_a','source_b'],columns='delay_s',values='information_ratio_uncertain')
im=ax.imshow(g.values,aspect='auto',vmin=.65,vmax=1.1)
ax.set_xticks(range(len(g.columns)),[f'{x:g}' for x in g.columns]);ax.set_yticks(range(len(g.index)),[f'prev {z[0]} · {z[1]}/{z[2]}' for z in g.index],fontsize=8)
ax.set(xlabel='Delay after previous OFF (s)',title='Source information ratio with previous-event uncertainty')
fig.colorbar(im,ax=ax,label='Recovery / equilibrium (1 means no change)')
fig.tight_layout();fig.savefig(F/'info_ratio_heatmap.png',dpi=210);fig.savefig(F/'info_ratio_heatmap.pdf');plt.close(fig)

# 5: sensitivity to model choice of colored noise
fig,ax=plt.subplots(figsize=(7.5,3.8))
q=a.query('channel_set=="all" and prior_sigma_b==0.01').groupby('rho')['d2_profiled'].median().reset_index()
ax.plot(q.rho,q.d2_profiled,'o-');ax.set(xlabel='AR(1) noise correlation rho',ylabel='Median profiled squared separation',title='Unmodeled instrument memory changes difficulty')
ax.grid(alpha=.25);fig.tight_layout();fig.savefig(F/'noise_correlation.png',dpi=210);fig.savefig(F/'noise_correlation.pdf');plt.close(fig)

# 6: channel ablation, predeclared source pair
fig,ax=plt.subplots(figsize=(7.5,3.7))
q=a.query('prior_bus==7 and delay_s==0.25 and rho==0.85 and prior_sigma_b==0.01')
order=['voltage_only','current_only','all'];v=[float(q[q.channel_set==s].d2_profiled.iloc[0]) for s in order]
ax.bar(['Voltage only','Oriented terminal current only','V + I'],v)
ax.set(ylabel='Profiled squared separation',title='Value of physically oriented current channels (BUS18/BUS27)')
ax.grid(axis='y',alpha=.25);fig.tight_layout();fig.savefig(F/'channel_ablation.png',dpi=210);fig.savefig(F/'channel_ablation.pdf');plt.close(fig)
print('figures written',len(list(F.glob('*.png'))))
