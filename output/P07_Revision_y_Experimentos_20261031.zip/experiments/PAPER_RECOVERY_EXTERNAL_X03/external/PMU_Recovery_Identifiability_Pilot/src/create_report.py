"""Readable Spanish PDF research report, figures from actual pilot outputs."""
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak,KeepTogether
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT
from xml.sax.saxutils import escape

ROOT=Path(__file__).resolve().parent.parent
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('DV',FONT));pdfmetrics.registerFont(TTFont('DV-Bold',BOLD))
path=ROOT/'INFORME_EXPERIMENTAL_RECOVERY_IEEE39_2026-10-31.pdf'
styles={
 'title':ParagraphStyle('title',fontName='DV-Bold',fontSize=17,leading=23,spaceAfter=14),
 'h1':ParagraphStyle('h1',fontName='DV-Bold',fontSize=12,leading=17,spaceBefore=10,spaceAfter=8),
 'h2':ParagraphStyle('h2',fontName='DV-Bold',fontSize=10,leading=15,spaceBefore=9,spaceAfter=5),
 'p':ParagraphStyle('p',fontName='DV',fontSize=8.7,leading=13.8,spaceAfter=7),
 'small':ParagraphStyle('small',fontName='DV',fontSize=7.6,leading=11,spaceAfter=6),
 'cell':ParagraphStyle('cell',fontName='DV',fontSize=7.7,leading=11),
 'cellb':ParagraphStyle('cellb',fontName='DV-Bold',fontSize=7.7,leading=11),
}

def P(t,ty='p'):return Paragraph(t,styles[ty])
def H(t):return P(t,'h1')
def fig(name,width=495):
    file=ROOT/'figures'/name
    from PIL import Image as PILImage
    im=PILImage.open(file); h=int(width*im.size[1]/im.size[0]);return Image(str(file),width=width,height=h)
def table(rows,widths):
    data=[]
    for i,rr in enumerate(rows):
        data.append([P(escape(str(x)), 'cellb' if i==0 else 'cell') for x in rr])
    tb=Table(data,colWidths=widths,hAlign='LEFT',repeatRows=1)
    tb.setStyle(TableStyle([
     ('LINEBELOW',(0,0),(-1,0),0.6,colors.grey),('LINEBELOW',(0,1),(-1,-1),0.18,colors.lightgrey),
     ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
     ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
    ]))
    return tb

def header_footer(canv,doc):
    canv.saveState()
    w,h=A4
    canv.setFont('DV',7.2);canv.setFillColor(colors.grey)
    canv.drawString(45,h-31,'PMU Fault Detection  ·  nota científica de laboratorio  ·  31 oct 2026')
    canv.line(45,h-35,w-45,h-35)
    canv.drawRightString(w-45,27,f'Pág. {doc.page}')
    canv.restoreState()

DOC=SimpleDocTemplate(str(path),pagesize=A4,rightMargin=45,leftMargin=45,topMargin=51,bottomMargin=45,
 title='Recovery-conditioned source identifiability – IEEE39 classical DAE pilot',author='Research audit',subject='Controlled research pilot; not full PowerDynamics')
body=[]
body.append(P('¿La recuperación de la red revela nuevas fuentes?\nExperimento físico-bayesiano en IEEE-39','title'))
body.append(P('<b>Dictamen:</b> el efecto de recuperación sobre la separabilidad es mixto y, al marginalizar incertidumbre de la historia, típicamente adverso en el piloto. La corrección de firmas físicas condicionadas sí reduce sesgo diagnóstico en parte de los escenarios, pero <b>no existe todavía una ventaja estadísticamente sólida ni una contribución nueva demostrada frente a R11/M³H</b>.'))
body.append(table([
 ['Variable', 'Resultado', 'Interpretación'],
 ['Modelo','IEEE-39 AC completo + 10 generadores swing clásicos, 39 voltajes algebraicos','No es PowerDynamics F01 ni AVR/TGOV1.'],
 ['Escenarios','108 configuraciones (2 eventos previos × 6 retardos × 3 pares × 3 horizontes)','Solo 6 grupos físicos por horizonte; medidas repetidas.'],
 ['Firmas congeladas, T=1.5s','67,14%','Dos fuentes conocidas, onset conocido.'],
 ['Firmas condicionadas, T=1.5s','71,51%','Mejora exploratoria +4,37 pp; no universal.'],
 ['Intervalo agrupado, 95%','−0,73 a +9,14 pp','Incluye cero; no afirmar superioridad.'],
 ['Separabilidad robusta','Mediana ratio 0,920; 1/36 por encima de 1','Recuperación no aumenta información de forma general.']
],[118,124,263]))
body.append(Spacer(1,8))
body.append(H('Qué se validó y qué no'))
body.append(P('La planta contiene las 46 ramas con sus taps y charging, un modelo clásico de máquina detrás de reactancia transitoria, cargas tipo impedancia y ocho buses instrumentados con voltajes y corrientes terminales rectangulares (32 coordenadas). Las ecuaciones se comprueban contra flujo AC y balances Kirchhoff. Las firmas se obtienen mediante dos contrafactuales que comienzan desde <b>el mismo estado dinámico previo</b>.'))
body.append(P('No se ejecutó el repositorio privado R11, la campaña C01, el modelo de sexto orden, ni las 47 coordenadas oficiales con frecuencia y ROCOF. El estado anterior es conocido por el simulador (oráculo); no es una estimación causal. El comparador de firmas congeladas sirve para una ablación, <b>no reemplaza IMM/M³H ni R11</b>.','small'))
body.append(PageBreak())

body.append(H('1. Ecuaciones que sí usa la implementación'))
body.append(P('Ecuación de Kirchhoff con generadores Norton y cargas Z:<br/><b>[Ybus(q) + Yload(a) + Ygen] · V = Igen(δ)</b>. Los generadores obedecen δ̇ = ωbΔω y 2HΔω̇ = Pm − Pe − DΔω. Los eventos anteriores modifican las cargas y se restauran exactamente; los estados diferenciales son continuos.'))
body.append(P('Para una segunda fuente s, el operador condicional se deriva de la trayectoria y los Jacobianos físicos:<br/><b>Ṡs = A(t)Ss + Bs(t), Ss(0)=0; Gs(t)=C(t)Ss(t)+Ds(t).</b><br/>A, B, C y D se calculan mediante sistemas de Kirchhoff y derivadas de potencia eléctrica, no mediante un modelo entrenado.'))
body.append(P('La distancia de fuentes se perfila respecto a la amplitud de la alternativa y usa una covarianza que incluye ruido AR(1), incertidumbre del primer evento y referencia angular común. Ratio = distancia durante recuperación / distancia en equilibrio. Un valor mayor que 1 indicaría una mejora de separación dentro de este contrato.'))
body.append(fig('information_vs_delay.png',480));body.append(P('Medianas para seis grupos físicos por retardo, horizonte de 1.5 s. La separación «ideal» omite incertidumbre en la severidad previa; la curva robusta la integra.','small'))
body.append(PageBreak())

body.append(H('2. El resultado contrario a la hipótesis de “excitación natural”'))
body.append(fig('info_ratio_heatmap.png',482))
body.append(P('Se muestran todos los grupos preestablecidos. Una intervención anterior puede cambiar las firmas sin mejorar su capacidad discriminante; el caso más difícil BUS18/BUS27 suele perder información. La única celda robusta mayor que 1 es un beneficio muy pequeño, no una ventaja general.','small'))
body.append(H('3. ¿El acondicionamiento al menos corrige el diagnóstico?'))
body.append(fig('pair_accuracy_vs_delay.png',482))
body.append(P('La exactitud de dos opciones aumenta en promedio al utilizar la firma calculada sobre el verdadero estado de recuperación; se trata de una prueba bajo estado previo oráculo y ruido sintético. Es compatible con una reducción de sesgo de modelado, no con mayor información intrínseca.','small'))
body.append(PageBreak())

body.append(H('4. Casos negativos y controles estadísticos'))
body.append(fig('paired_accuracy_by_physical_group.png',482))
body.append(P('En los dos grupos BUS18/BUS27, la firma condicionada reduce la exactitud. La mejora promedio (+4.37 pp) no representa todos los casos. El bootstrap exploratorio sobre solamente seis grupos físicos produce un intervalo 95% que incluye cero: [−0.73, +9.14] pp. No se debe reportar como un resultado confirmatorio.','small'))
body.append(H('5. Sensibilidad a la memoria instrumental'))
body.append(fig('noise_correlation.png',482))
body.append(P('La separación disminuye fuertemente al representar dependencia temporal. Reportar datos a 30 Hz no equivale a disponer de 30 mediciones independientes por segundo. Este gráfico procede de un análisis de sensibilidad del modelo de ruido, no de una identificación real de ruido PMU.','small'))
body.append(PageBreak())

body.append(H('6. Comprobación del operador dinámico y sensores'))
body.append(table([
 ['Control físico/número','Resultado'],
 ['KCL inicial','2,29×10⁻¹³ pu'],
 ['Deriva en equilibrio','Dentro de las tolerancias ODE'],
 ['Operador analítico vs diferencias finitas','Errores relativos 3,5×10⁻⁹ a 1,7×10⁻⁸ (seis comparaciones)'],
 ['Operador a amplitud finita a=0,0006','Errores relativos aprox. 0,02%–0,045% para BUS18/BUS27'],
 ['Tiempo de operador tangente vs 6 simulaciones FD','No hay mejora consistente de latencia en esta implementación Python']
],[255,250]))
body.append(Spacer(1,10));body.append(fig('channel_ablation.png',482))
body.append(P('Ablación BUS18/BUS27, historia BUS7, Δ=0,25 s. Las corrientes terminales contienen gran parte de la separación bajo el mapa instrumental ilustrativo. No extrapolar a los terminales reales de RAW0001 sin auditar su orientación.','small'))
body.append(PageBreak())

body.append(H('7. Qué debería hacer Codex antes de alterar el artículo'))
body.append(table([
 ['Prioridad','Acción y criterio de aceptación'],
 ['P0','Abrir el repositorio real, congelar R11/H04/C01 y comprobar la planta F01, sensores y callbacks ON/OFF.'],
 ['P0','Construir el operador tangente para la DAE Sauer–Pai/AVR/TGOV1/ZIP real; comprobar FD contra TDS completa y la discrepancia histórica de segundo orden.'],
 ['P0','Eliminar el oráculo: obtener el estado y covarianza pre-evento de PMU causales, sin reutilizar la verdad simulada.'],
 ['P1','Integrar dos fuentes débiles y líneas conmutadas; comparación de cardinalidad K=1/2 y fuentes con R11, IMM/M³H y baselines de entradas dispersas.'],
 ['P1','Ejecutar evaluación independiente a nivel de padre físico, ruido calibrado, máscaras PMU, costo extremo a extremo y sin abrir TEST para seleccionar parejas.'],
 ['GO/NO GO','Solo reescribir el paper alrededor de este mecanismo si mejora una tarea bajo el mismo contrato físico, o la escala computacional, sin empeorar de forma oculta pares difíciles.']
],[83,422]))
body.append(Spacer(1,9))
body.append(P('<b>Interpretación de novedad:</b> Kirchhoff, swing, DAE, las ecuaciones tangentes, el filtro gaussiano, la evidencia integrada y la recuperación de estados son herramientas conocidas. R11 ya construye predictores desde estados anteriores. Una contribución defensible necesitaría una operación inferencial distinta y una ventaja demostrada contra métodos históricamente más cercanos que el control «frozen signatures».'))
body.append(P('<b>Artefactos:</b> código Python completo, 108 configuraciones experimentales, resultados de seis grupos físicos, comprobaciones tangentes, ablaciones de ruido/canales, gráficos y guía `docs/CODEX_PORT_FULL_DAE.md` en el ZIP.','small'))
body.append(P('<b>Referencias base:</b> manuscrito R11 de 15 páginas del proyecto; MATPOWER case39.m; Blom y Bar-Shalom (IMM, 1988); Boers y Driessen (M³H, 2005); Anguluri, Kosut y Sankar (Group LASSO, 2023); formulaciones clásicas de estabilidad swing–Norton–Kirchhoff. Las pruebas de este informe no reproducen las campañas de estos autores.','small'))
DOC.build(body,onFirstPage=header_footer,onLaterPages=header_footer)
print(path)
