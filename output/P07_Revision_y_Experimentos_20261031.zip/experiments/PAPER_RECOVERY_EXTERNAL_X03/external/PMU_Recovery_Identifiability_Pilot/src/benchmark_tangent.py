"""Benchmark of current *unoptimized* Python tangent against FD rollouts.
Fair same simplified plant, 1.5 sec horizon, 3 source locations; check tolerances.
The goal is to REJECT unsupported speed claims, not to manufacture a benefit.
"""
import json,time
import numpy as np
from pathlib import Path
from swing39 import Swing39
from tangent39 import propagate_tangents
m=Swing39(); x=m.prefix_state(7,.08,1.25);sources=[18,27,16];T=1.5
rows=[]
for rep in range(3):
    t=time.perf_counter();_,_,d=propagate_tangents(m,x,sources,T,rtol=1e-9,atol=1e-11);dt=time.perf_counter()-t
    t=time.perf_counter()
    fd=[]
    for s in sources:
      _,_,yp=m.fork(x,T,s,.0002);_,_,ym=m.fork(x,T,s,-.0002)
      fd.append((yp-ym)/.0004)
    dfd=time.perf_counter()-t
    rel=[float(np.linalg.norm(fd[k]-d[:,:,k])/np.linalg.norm(fd[k])) for k in range(len(sources))]
    rows.append({'repeat':rep,'tangent_wall_s':dt,'FD_6_rollouts_wall_s':dfd,'tangent_vs_FD_speedup':dfd/dt,'max_rel_error':max(rel)})
print(json.dumps(rows,indent=2))
root=Path(__file__).resolve().parent.parent
(root/'results'/'runtime_tangent_vs_fd.json').write_text(json.dumps(rows,indent=2))
