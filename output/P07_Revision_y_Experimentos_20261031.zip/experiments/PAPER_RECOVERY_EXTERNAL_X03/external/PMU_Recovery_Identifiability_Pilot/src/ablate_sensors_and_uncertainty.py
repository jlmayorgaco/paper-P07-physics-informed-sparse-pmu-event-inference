"""Ablations of graph observability, uncertain previous load, and AR1 memory.
Uses same simplified swing+KCL IEEE39; select two prior buses, two delays,
near-confusable pair 18/27. No claim of sensor-optimality or full DAE results.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from swing39 import Swing39
from tangent39 import propagate_tangents
from run_pilot import phase_deriv,whiten_ar1,distance

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'results'
model=Swing39();T=1.5;fps=30;a=0.0006;sources=[18,27]
results=[]
for prior in (7,24):
 for delay in (0.25,2.0):
  tau=1+delay;x=model.prefix_state(prior,.08,tau)
  _,_,ref=model.fork(x,T,fps=fps)
  _,_,tang=propagate_tangents(model,x,sources,T,fps)
  xp=model.prefix_state(prior,.082,tau);xm=model.prefix_state(prior,.078,tau)
  _,_,yp=model.fork(xp,T,fps=fps)
  _,_,ym=model.fork(xm,T,fps=fps)
  Jb=(yp-ym)/.004
  for j,s in enumerate(sources):
   _,_,ye=model.fork(x,T,s,a,fps=fps)
   rel=float(np.linalg.norm((ye-ref)/a-tang[:,:,j])/np.linalg.norm((ye-ref)/a))
   print('TANGENT FIT:',prior,delay,s,rel,flush=True)
   assert rel<0.005
  for channel in ['all','voltage_only','current_only']+['drop_pmu_'+str(b) for b in (2,5,6,10,19,22,29,39)]:
   ids=[]
   for k,pmu in enumerate((2,5,6,10,19,22,29,39)):
    if channel=='voltage_only':ids.extend([4*k,4*k+1])
    elif channel=='current_only':ids.extend([4*k+2,4*k+3])
    elif channel==f'drop_pmu_{pmu}':pass
    else:ids.extend([4*k+z for z in range(4)])
   if channel.startswith('drop_pmu_'):
    omit=int(channel.split('_')[-1]);ids=[i for i in range(32) if i//4!=(2,5,6,10,19,22,29,39).index(omit)]
   idx=np.array(ids,dtype=int);sig=model.ac.noise_scale()[idx]
   g1=tang[:,idx,0];g2=tang[:,idx,1]
   phase=phase_deriv(ref)[:,idx];j=Jb[:,idx]
   for rho in ([0.,0.5,0.85,0.95] if channel=='all' else [0.85]):
    z1=whiten_ar1(g1,sig,rho);z2=whiten_ar1(g2,sig,rho)
    jph=whiten_ar1(phase,sig,rho);jb=whiten_ar1(j,sig,rho)
    for sb in ([0.,0.003,0.01,0.03] if channel=='all' else [0.01]):
     U=np.column_stack([sb*jb,.003*jph])
     val=distance(z1,z2,U,a)
     results.append({'prior_bus':prior,'delay_s':delay,'channel_set':channel,'rho':rho,'prior_sigma_b':sb,
                     'd2_profiled':val,'n_coords':len(idx),'d2_asymmetry_note':'minimum of both source directions, amplitude profiled nonnegative'})
  print('finished primary',prior,'delay',delay,flush=True)
df=pd.DataFrame(results);df.to_csv(OUT/'sensor_noise_nuisance_ablations.csv',index=False)
print('ABLATION COUNT',len(df),flush=True)
