"""DAE-consistent source-to-PMU tangent operators for simplified IEEE39 swing network.

For the classical grid in swing39.py, eliminate 39 complex algebraic nodal
voltages using sparse-graph admittance and generator Norton equivalents; solve
nonlinear 10-generator swing trajectory and linear time-varying forward tangent
systems simultaneously for multiple node load sources. NO finite differences
inside tangent construction. Validate against perturbed nonlinear simulations.

This is not full Sauer-Pai/TGOV1/AVR physics of SGSMA's PowerDynamics R11.
"""
from __future__ import annotations
import time
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import lu_solve
from swing39 import Swing39,GEN_BUS,OMEGA_BASE,BRANCH,PMUS


def measurement_M(model):
    M=np.zeros((16,39),dtype=complex)
    for j,pmu in enumerate(PMUS):
        M[2*j,pmu-1]=1.0
        k,bus=model.ac.branch_selection[j]
        f,t,r,x,b,tap=BRANCH[k]
        f=int(f)-1;t=int(t)-1
        yc=1/complex(r,x);rat=float(tap) if tap else 1.0
        if int(bus)==f+1:
            M[2*j+1,f]=(yc+1j*b/2)/(rat*rat)
            M[2*j+1,t]=-yc/rat
        else:
            M[2*j+1,t]=yc+1j*b/2
            M[2*j+1,f]=-yc/rat
    return M


def real32(z):
    return np.stack([z.real,z.imag],axis=-1).reshape(32,-1)


def jacobian(model,x,source_buses=(),amps=None):
    """Analytical tangent of differential + algebraic network output.

    Returns F, A = dF/dx, B = dF/da, measured y, Hx, Ha.
    Direct algebraic sensitivities include source admittance effect.
    All network derivatives are evaluated by LU solves of complex KCL.
    """
    if amps is None:amps=np.zeros(39)
    E=model.internal_emf(x); V,Ig=model.network(x,amps)
    n=len(source_buses)
    rhs=np.zeros((39,10+n),complex)
    rhs[GEN_BUS,np.arange(10)]=model.norton*(1j*E)
    for k,bus in enumerate(source_buses):
        i=bus-1
        rhs[i,10+k]=-model.yload[i]*V[i]
    dV=lu_solve(model._factor(amps),rhs,check_finite=False)
    vdelta=dV[:,:10]
    vsrc=dV[:,10:]
    dg=np.diag(1j*E)
    dIgdelta=model.norton[:,None]*(dg-vdelta[GEN_BUS,:])
    dIgsrc=-model.norton[:,None]*vsrc[GEN_BUS,:]
    dPedelta=np.real(dg*np.conj(Ig[:,None])+E[:,None]*np.conj(dIgdelta))
    dPesrc=np.real(E[:,None]*np.conj(dIgsrc))
    w=x[10:]; Pe=np.real(E*np.conj(Ig))
    f=np.r_[OMEGA_BASE*w,(model.Pm-Pe-model.D*w)/(2*model.H)]
    A=np.zeros((20,20));A[:10,10:]=OMEGA_BASE*np.eye(10)
    A[10:,:10]=-dPedelta/(2*model.H[:,None]);A[10:,10:]=-np.diag(model.D/(2*model.H))
    B=np.zeros((20,n));B[10:]=-dPesrc/(2*model.H[:,None])
    M=measurement_M(model)
    obs=M@V
    Dy=M@vdelta
    Da=M@vsrc
    # Real coordinate order Vre,Vim,Ire,Iim for each PMU.
    y=np.stack([obs.real,obs.imag],axis=1).reshape(32)
    Hx=np.zeros((32,20)); Hx[:,:10]=np.stack([Dy.real,Dy.imag],axis=1).reshape(32,10)
    Ha=np.stack([Da.real,Da.imag],axis=1).reshape(32,n)
    return f,A,B,y,Hx,Ha


def propagate_tangents(model,x0,source_buses,T=1.5,fps=30,rtol=1e-8,atol=1e-10):
    """Compute exact 1st-order d PMU(t) / d load_fraction(source) via tangent DAE.

    Source turns ON at t=0 and stays active during the window.
    We integrate nominal recovery x(t) (no second event) and S'=AS+B,
    S(0)=0; output sensitivity G(t)=Hx(t) S(t)+Ha(t).
    """
    n=len(source_buses)
    y0=np.r_[np.asarray(x0,dtype=float),np.zeros(20*n)]
    zeros=np.zeros(39)
    def rhs(t,z):
        x=z[:20];S=z[20:].reshape(20,n)
        f,A,B,_,_,_=jacobian(model,x,source_buses,zeros)
        return np.r_[f,(A@S+B).ravel()]
    t_eval=np.linspace(0,T,int(round(T*fps))+1)
    sol=solve_ivp(rhs,(0.,T),y0,t_eval=t_eval,rtol=rtol,atol=atol,method='DOP853',max_step=model.max_step)
    if not sol.success:raise RuntimeError(sol.message)
    out=np.empty((len(t_eval),32,n))
    for it in range(len(t_eval)):
        x=sol.y[:20,it];S=sol.y[20:,it].reshape(20,n)
        f,A,B,y,Hx,Ha=jacobian(model,x,source_buses,zeros)
        out[it]=Hx@S+Ha
    return t_eval,sol.y[:20].T,out


def validate():
    model=Swing39()
    print('evaluating exact tangent operators...',flush=True)
    cases=[('equilibrium',model.x0,[18,27,16]),('during-recovery',model.prefix_state(7,.08,1.25),[18,27,16])]
    records=[]
    for name,x,sources in cases:
        t0=time.perf_counter()
        ts,xx,D=propagate_tangents(model,x,sources)
        compute_tangent=time.perf_counter()-t0
        _,_,base=model.fork(x,1.5)
        for k,s in enumerate(sources):
            eps=2e-4
            _,_,yp=model.fork(x,1.5,s,eps)
            _,_,ym=model.fork(x,1.5,s,-eps)
            fd=(yp-ym)/(2*eps)
            rel=float(np.linalg.norm(fd-D[:,:,k])/np.linalg.norm(fd))
            worst=float(np.max(np.abs(fd-D[:,:,k])))
            records.append({'case':name,'bus':s,'rel_error':rel,'max_abs':worst,'tangent_time_seconds':compute_tangent,'max_sensitivity':float(np.max(np.abs(D[:,:,k])))})
            print(name,s,'rel_err',rel,'maxabs',worst,'tangent time',round(compute_tangent,2),flush=True)
        assert max(r['rel_error'] for r in records if r['case']==name)<0.01
    return records

if __name__=='__main__':
    import json
    from pathlib import Path
    rec=validate()
    root=Path(__file__).resolve().parent.parent
    (root/'results'/'tangent_validation.json').write_text(json.dumps(rec,indent=2))
