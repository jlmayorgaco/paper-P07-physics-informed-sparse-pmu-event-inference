"""Runnable mathematical, physical, and probabilistic invariants."""
import numpy as np
from scipy.integrate import quad
from scipy.stats import norm
from swing39 import Swing39
from tangent39 import jacobian,propagate_tangents
from run_pilot import inv_prod,distance,evidences,whiten_ar1

m=Swing39();n=0

def check(msg,condition):
 global n
 assert bool(condition),msg
 n+=1; print('PASS:',msg)

check('AC voltage reconstruction',m.initial_max_V_err<1e-10)
check('KCL algebraic residual',m.initial_KCL_err<1e-10)
check('equilibrium differential residual',m.initial_max_swing_err<1e-10)
_,xe,_=m.fork(m.x0,1.0)
check('equilibrium simulated drift',np.max(abs(xe-m.x0))<1e-9)
xzero=m.prefix_state(7,0,1.5)
check('no prior disturbance gives equilibrium',np.max(abs(xzero-m.x0))<1e-9)
for name,x in [('equilibrium',m.x0),('recovery',m.prefix_state(7,.08,1.25))]:
 ts,xx,tang=propagate_tangents(m,x,[18,27],T=.5)
 for i,s in enumerate([18,27]):
  _,_,yp=m.fork(x,.5,s,.0002);_,_,ym=m.fork(x,.5,s,-.0002)
  FD=(yp-ym)/.0004
  error=np.linalg.norm(FD-tang[:,:,i])/np.linalg.norm(FD)
  check(f'{name}, BUS{s} source tangent matches FD',error<1e-5)
# Verify correlated covariance marginalization and evidence using dense baseline
r=np.array([.4,-.2,.15,1.]);g=np.array([.8,.1,-.2,.3]);U=np.array([[.2,.4],[.1,-.3],[-.2,.1],[.3,.2]])
C=np.eye(4)+U@U.T
check('Woodbury inverse is full covariance inverse',np.allclose(inv_prod(r,U),np.linalg.solve(C,r),atol=1e-12))
# Bayes source vs no-source: match one-dimensional quadrature under Gaussian amplitude.
sa=.7;ga=np.array([.8,.1,-.2,.3]);gb=np.array([.2,.6,-.1,.1])
la,lb=evidences(r.reshape(1,-1),ga,gb,U,sa)
for label,g,z in [('a',ga,la[0]),('b',gb,lb[0])]:
 lik=quad(lambda a:np.exp(-.5*((r-a*g)@np.linalg.solve(C,r-a*g)-r@np.linalg.solve(C,r)))*norm.pdf(a,0,sa),-7,7,epsabs=1e-12)[0]
 check(f'Bayesian evidence {label} agrees with quadrature',abs(z-np.log(lik))<1e-9)
check('profiled source distance nonnegative',distance(ga,gb,U,.01)>=0)
# Constant observations whiten AR1 yields finite valid return.
W=whiten_ar1(np.zeros((4,4)),np.ones(4),.9)
check('AR1 whitening for zero signal',np.all(W==0))
print(f'{n}/{n} verified checks')
