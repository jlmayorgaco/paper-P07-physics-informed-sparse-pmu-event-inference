"""A separately identified IEEE-39 *STATIC AC* power-flow proxy.

Numerical parameters transcribed from MATPOWER case39.m (accessed 2026-10-30):
https://raw.githubusercontent.com/MATPOWER/matpower/master/data/case39.m
This is NOT the user's PowerDynamics / ANDES dynamic DAE nor original SGSMA dataset.

Bus type PV 30,32..39; slack 31. The solved MATPOWER starting values are
held as a Newton initial guess, not treated as measured truth. Generator
reactive output varies to maintain PV voltages; Q limits are not enforced.
"""
from dataclasses import dataclass
from functools import cached_property
import numpy as np
from scipy.optimize import root

# bus | Pd (MW) | Qd (MVAr) | Vm (pu) | Va (degrees), from MATPOWER case39.m
BUS = np.array([
[1,97.6,44.2,1.0393836,-13.536602],[2,0,0,1.0484941,-9.7852666],
[3,322,2.4,1.0307077,-12.276384],[4,500,184,1.00446,-12.626734],
[5,0,0,1.0060063,-11.192339],[6,0,0,1.0082256,-10.40833],
[7,233.8,84,.99839728,-12.755626],[8,522,176.6,.99787232,-13.335844],
[9,6.5,-66.6,1.038332,-14.178442],[10,0,0,1.0178431,-8.170875],
[11,0,0,1.0133858,-8.9369663],[12,8.53,88,1.000815,-8.9988236],
[13,0,0,1.014923,-8.9299272],[14,0,0,1.012319,-10.715295],
[15,320,153,1.0161854,-11.345399],[16,329,32.3,1.0325203,-10.033348],
[17,0,0,1.0342365,-11.116436],[18,158,30,1.0315726,-11.986168],
[19,0,0,1.0501068,-5.4100729],[20,680,103,.99101054,-6.8211783],
[21,274,115,1.0323192,-7.6287461],[22,0,0,1.0501427,-3.1831199],
[23,247.5,84.6,1.0451451,-3.3812763],[24,308.6,-92.2,1.038001,-9.9137585],
[25,224,47.2,1.0576827,-8.3692354],[26,139,17,1.0525613,-9.4387696],
[27,281,75.5,1.0383449,-11.362152],[28,206,27.6,1.0503737,-5.9283592],
[29,283.5,26.9,1.0501149,-3.1698741],[30,0,0,1.0499,-7.3704746],
[31,9.2,4.6,.982,0],[32,0,0,.9841,-.1884374],
[33,0,0,.9972,-.19317445],[34,0,0,1.0123,-1.631119],
[35,0,0,1.0494,1.7765069],[36,0,0,1.0636,4.4684374],
[37,0,0,1.0275,-1.5828988],[38,0,0,1.0265,3.8928177],
[39,1104,250,1.03,-14.535256]], dtype=float)
# from, to, series r, x, total line charging b, offnominal tap (0 -> 1)
BRANCH = np.array([
[1,2,.0035,.0411,.6987,0],[1,39,.001,.025,.75,0],
[2,3,.0013,.0151,.2572,0],[2,25,.007,.0086,.146,0],[2,30,0,.0181,0,1.025],
[3,4,.0013,.0213,.2214,0],[3,18,.0011,.0133,.2138,0],
[4,5,.0008,.0128,.1342,0],[4,14,.0008,.0129,.1382,0],
[5,6,.0002,.0026,.0434,0],[5,8,.0008,.0112,.1476,0],
[6,7,.0006,.0092,.113,0],[6,11,.0007,.0082,.1389,0],[6,31,0,.025,0,1.07],
[7,8,.0004,.0046,.078,0],[8,9,.0023,.0363,.3804,0],[9,39,.001,.025,1.2,0],
[10,11,.0004,.0043,.0729,0],[10,13,.0004,.0043,.0729,0],[10,32,0,.02,0,1.07],
[12,11,.0016,.0435,0,1.006],[12,13,.0016,.0435,0,1.006],
[13,14,.0009,.0101,.1723,0],[14,15,.0018,.0217,.366,0],
[15,16,.0009,.0094,.171,0],[16,17,.0007,.0089,.1342,0],
[16,19,.0016,.0195,.304,0],[16,21,.0008,.0135,.2548,0],
[16,24,.0003,.0059,.068,0],[17,18,.0007,.0082,.1319,0],
[17,27,.0013,.0173,.3216,0],[19,20,.0007,.0138,0,1.06],
[19,33,.0007,.0142,0,1.07],[20,34,.0009,.018,0,1.009],
[21,22,.0008,.014,.2565,0],[22,23,.0006,.0096,.1846,0],
[22,35,0,.0143,0,1.025],[23,24,.0022,.035,.361,0],
[23,36,.0005,.0272,0,1],[25,26,.0032,.0323,.531,0],
[25,37,.0006,.0232,0,1.025],[26,27,.0014,.0147,.2396,0],
[26,28,.0043,.0474,.7802,0],[26,29,.0057,.0625,1.029,0],
[28,29,.0014,.0151,.249,0],[29,38,.0008,.0156,0,1.025]
],dtype=float)
# generator P (MW) for generator buses 30..39
PGEN = np.array([250, 677.871, 650,632,508,650,560,540,830,1000.])
PMUS = np.array([2,5,6,10,19,22,29,39],dtype=int)
# Illustrative 16 PQ load buses; NOT inferred to match the original IEEE39 DAE candidate list
SOURCES = np.array([1,3,4,7,8,15,16,18,20,21,23,24,25,26,27,28],dtype=int)

@dataclass
class AC39:
    """AC power-flow with PQ/PV/slack constraints and power/branch terminal PMU map."""
    noise_v:float = 2e-4
    noise_i:float = 1e-3
    def __post_init__(self):
        self.pq=np.arange(29)
        self.slack=30  # bus31, zero based
        self.pv=np.array([i for i in range(29,39) if i!=self.slack])
        self.non_slack=np.array([i for i in range(39) if i!=self.slack])
        self.vm0=BUS[:,3].copy();self.ang0=np.deg2rad(BUS[:,4])
        self.base_sol=np.r_[self.ang0[self.non_slack],self.vm0[self.pq]]
        self.pgen=np.zeros(39);self.pgen[29:39]=PGEN/100.
        self.branch_selection=[]
        for pmu in PMUS:
            idx=np.where((BRANCH[:,0]==pmu)|(BRANCH[:,1]==pmu))[0]
            if len(idx)<1:raise ValueError('missing terminal branch')
            self.branch_selection.append((int(idx[0]),int(pmu)))
    def ybus(self,branch_factors=None):
        factors=np.ones(len(BRANCH)) if branch_factors is None else np.asarray(branch_factors)
        if factors.shape!=(len(BRANCH),):raise ValueError('line factor shape')
        Y=np.zeros((39,39),dtype=complex)
        for k,(ff,tt,r,x,b,tap) in enumerate(BRANCH):
            f=int(ff)-1;t=int(tt)-1
            # relative perturbation of series impedance (R and X together)
            y=1/(factors[k]*(r+1j*x)); t0=tap if tap else 1.
            yff=(y+1j*b/2)/t0**2; ytt=y+1j*b/2
            yft=-y/t0
            Y[f,f]+=yff;Y[t,t]+=ytt;Y[f,t]+=yft;Y[t,f]+=yft
        return Y
    def voltages(self,w):
        ang=self.ang0.copy();ang[self.non_slack]=w[:len(self.non_slack)]
        vm=self.vm0.copy();vm[self.pq]=w[len(self.non_slack):]
        return vm*np.exp(1j*ang)
    def solve(self,amps=None,load_shift=0.,branch_factors=None,init=None):
        a=np.zeros(39) if amps is None else np.asarray(amps)
        if a.shape!=(39,):raise ValueError('amplitudes must be 39 bus values')
        if np.any(1+load_shift+a <= 0):raise ValueError('negative load scale')
        Y=self.ybus(branch_factors)
        pd=BUS[:,1]/100*(1+load_shift+a)
        qd=BUS[:,2]/100*(1+load_shift+a)
        p_spec=self.pgen-pd
        def fun(w):
            V=self.voltages(w)
            S=V*np.conj(Y@V)
            return np.r_[S.real[self.non_slack]-p_spec[self.non_slack],
                         S.imag[self.pq]+qd[self.pq]]
        fit=root(fun,self.base_sol if init is None else init,tol=2e-10)
        err=np.max(np.abs(fun(fit.x)))
        if (not np.all(np.isfinite(fit.x))) or err>1e-7:raise RuntimeError(f'AC solve nonconverged err={err:.3g}')
        V=self.voltages(fit.x)
        return V,Y,float(err),fit.x
    def measured(self,V,branch_factors=None):
        f=np.ones(len(BRANCH)) if branch_factors is None else np.asarray(branch_factors)
        result=[]
        for i,pmu in enumerate(PMUS):
            k,pmu_bus=self.branch_selection[i]
            fr,to,r,x,b,tap=BRANCH[k];fr=int(fr)-1;to=int(to)-1
            y=1/(f[k]*(r+1j*x));t0=tap if tap else 1.
            if pmu_bus==fr+1:
                I=(y+1j*b/2)/t0**2*V[fr]-y/t0*V[to]
            else:
                I=(y+1j*b/2)*V[to]-y/t0*V[fr]
            v=V[pmu_bus-1]
            result.extend([v.real,v.imag,I.real,I.imag])
        return np.array(result)
    def predict(self,support=(),a=(),load_shift=0.,branch_factors=None):
        amps=np.zeros(39)
        for b,amp in zip(support,a):amps[int(b)-1]=amp
        V,_,err,_=self.solve(amps,load_shift=load_shift,branch_factors=branch_factors)
        return self.measured(V,branch_factors)
    def noise_scale(self):
        return np.tile([self.noise_v,self.noise_v,self.noise_i,self.noise_i],len(PMUS))


def shift_draw(rng,scale=.012):
    """3 independent series R/X scaling perturbations plus global PQ demand shift."""
    bf=np.ones(len(BRANCH))
    for pair in ((2,3),(6,7),(16,17)):
        hits=np.where((BRANCH[:,0]==pair[0])&(BRANCH[:,1]==pair[1]))[0]
        bf[hits[0]]=1+rng.normal(0,scale)
    return float(rng.normal(0,scale)),bf
