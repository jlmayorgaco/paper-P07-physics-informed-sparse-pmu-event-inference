"""Controlled recovery-dependent source separability test, IEEE39 classical DAE.

NOT the original SGSMA PowerDynamics R11/F01 simulation. R11 not run.
Known onset, two-candidate classification, x_tau from simulator, uncertainty
in previous event amplitude and global phase, AR1 Gaussian observation noise.

Generate prior load ON 0.2s, OFF 1.0s; fork same state at 1+delay into
recovery-only and weak second source. Compare nonlinear incremental response
with equilibrium, compute nuisance-profiled physical distances, use a Gaussian
amplitude-marginalized Bayesian source comparison on held-out noise draws.
"""
from __future__ import annotations
import json,time
from pathlib import Path
import numpy as np
from swing39 import Swing39

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'results';OUT.mkdir(parents=True,exist_ok=True)
CONFIG={
 'model':'10 classical swing generators + MATPOWER IEEE39 46-branch graph + fixed impedance loads',
 'not_model':'SGSMA original PowerDynamics Sauer-Pai/TGOV1/AVR/ZIP/R11 model',
 'prior_load_buses':[7,24], 'prior_fraction_of_original_load':0.08,
 'prior_load_on_s':0.2,'prior_load_off_s':1.0,
 'secondary_candidate_pairs':[[18,27],[16,21],[3,21]],
 'secondary_event_amplitude_fraction':0.0006,'event_amplitude_gaussian_prior_std':0.0015,
 'delays_since_prior_off_s':[0.,0.25,0.5,1.,2.,4.],
 'decision_horizons_s':[0.3,1.,1.5], 'fps':30,
 'sigma_voltage_component_pu':0.0002,'sigma_current_component_pu':0.0010,
 'AR1_noise_rho':0.85, 'prior_load_fraction_uncertainty_std':0.01,
 'global_phase_offset_uncertainty_std_rad':0.003,
 'noise_draws_per_true_source':300,'seed':20261031,
 'caveats':'Simplified classical model, oracle physical x_tau and recovery-only baseline; known previous bus and second-event onset; binary source candidates only; no PMU hardware signal chain.'
}
def phase_deriv(y):
 z=np.asarray(y).reshape(len(y),16,2)
 return np.stack([-z[:,:,1],z[:,:,0]],axis=-1).reshape(len(y),32)
def whiten_ar1(a,sig,rho):
 scaled=np.asarray(a,dtype=float)/sig[None,:]
 w=scaled.copy();w[1:]=(scaled[1:]-rho*scaled[:-1])/np.sqrt(1-rho*rho)
 return w.ravel()
def inv_prod(v,U):
 v=np.asarray(v,dtype=float)
 if not U.shape[1]:return v
 return v-U@np.linalg.solve(np.eye(U.shape[1])+U.T@U,U.T@v)
def ip(v,w,U):return float(v@inv_prod(w,U))
def distance(va,vb,U,amplitude):
 ds=[]
 for a,b in ((va,vb),(vb,va)):
  a=amplitude*a;b=amplitude*b
  aa=ip(a,a,U);ab=ip(a,b,U);bb=ip(b,b,U)
  coeff=max(0.,ab/max(bb,1e-20))
  ds.append(max(0.,aa-2*coeff*ab+coeff*coeff*bb))
 return min(ds)
def evidences(samples,ga,gb,U,sa):
 ia=inv_prod(ga,U);ib=inv_prod(gb,U)
 aa=float(ga@ia);bb=float(gb@ib);v=sa*sa
 return (.5*(v*(samples@ia)**2/(1+v*aa)-np.log1p(v*aa)),
         .5*(v*(samples@ib)**2/(1+v*bb)-np.log1p(v*bb)))
def accuracy_draw(rng,ga_true,gb_true,ga_test,gb_test,U,amp,sa,n):
 z=rng.standard_normal((2*n,len(ga_true)))
 if U.shape[1]:z+=rng.standard_normal((2*n,U.shape[1]))@U.T
 z[:n]+=amp*ga_true;z[n:]+=amp*gb_true
 ea,eb=evidences(z,ga_test,gb_test,U,sa)
 return float((np.sum(ea[:n]>eb[:n])+np.sum(eb[n:]>ea[n:]))/(2*n))
def run():
 rng=np.random.default_rng(CONFIG['seed']);st=time.time();model=Swing39()
 sig=model.ac.noise_scale();rho=CONFIG['AR1_noise_rho'];a=CONFIG['secondary_event_amplitude_fraction'];fps=CONFIG['fps'];T=max(CONFIG['decision_horizons_s'])
 _,_,y0=model.fork(model.x0,T,fps=fps)
 src=sorted(set(b for pair in CONFIG['secondary_candidate_pairs'] for b in pair))
 eq={}
 for b in src:
  _,_,y=model.fork(model.x0,T,b,a,fps=fps)
  eq[b]=y-y0
 print('equilibrium source signatures',len(src),'elapsed_s',round(time.time()-st,2),flush=True)
 rows=[]
 for prior in CONFIG['prior_load_buses']:
  b=CONFIG['prior_fraction_of_original_load']
  for delay in CONFIG['delays_since_prior_off_s']:
   tau=1.+delay;x=model.prefix_state(prior,b,tau)
   _,_,ref=model.fork(x,T,fps=fps)
   db=.002
   xp=model.prefix_state(prior,b+db,tau);xm=model.prefix_state(prior,b-db,tau)
   _,_,yp=model.fork(xp,T,fps=fps);_,_,ym=model.fork(xm,T,fps=fps)
   jb=(yp-ym)/(2*db)
   rec={}
   for s in src:
    _,_,ys=model.fork(x,T,s,a,fps=fps);rec[s]=ys-ref
   for horizon in CONFIG['decision_horizons_s']:
    k=int(round(horizon*fps))+1
    uw=whiten_ar1(phase_deriv(ref[:k]),sig,rho)
    bw=whiten_ar1(jb[:k],sig,rho)
    U=np.column_stack([CONFIG['prior_load_fraction_uncertainty_std']*bw,CONFIG['global_phase_offset_uncertainty_std_rad']*uw])
    u0=whiten_ar1(phase_deriv(y0[:k]),sig,rho)
    Ueq=np.column_stack([np.zeros_like(u0),CONFIG['global_phase_offset_uncertainty_std_rad']*u0])
    for s1,s2 in CONFIG['secondary_candidate_pairs']:
     e1=whiten_ar1(eq[s1][:k]/a,sig,rho);e2=whiten_ar1(eq[s2][:k]/a,sig,rho)
     h1=whiten_ar1(rec[s1][:k]/a,sig,rho);h2=whiten_ar1(rec[s2][:k]/a,sig,rho)
     d0=distance(e1,e2,Ueq,a)
     d_ideal=distance(h1,h2,np.column_stack([np.zeros_like(uw),CONFIG['global_phase_offset_uncertainty_std_rad']*uw]),a)
     d_unc=distance(h1,h2,U,a)
     state=rng.bit_generator.state
     acc_new=accuracy_draw(rng,h1,h2,h1,h2,U,a,CONFIG['event_amplitude_gaussian_prior_std'],CONFIG['noise_draws_per_true_source'])
     state2=rng.bit_generator.state;rng.bit_generator.state=state
     acc_old=accuracy_draw(rng,h1,h2,e1,e2,U,a,CONFIG['event_amplitude_gaussian_prior_std'],CONFIG['noise_draws_per_true_source'])
     rng.bit_generator.state=state2
     acc_eq=accuracy_draw(rng,e1,e2,e1,e2,Ueq,a,CONFIG['event_amplitude_gaussian_prior_std'],CONFIG['noise_draws_per_true_source'])
     rows.append(dict(prior_bus=prior,delay_s=delay,horizon_s=horizon,source_a=s1,source_b=s2,
      prior_state_change_norm=float(np.linalg.norm(x-model.x0)),
      d2_equilibrium=d0,d2_recovery_ideal=d_ideal,d2_recovery_uncertain=d_unc,
      information_ratio_ideal=d_ideal/max(d0,1e-10), information_ratio_uncertain=d_unc/max(d0,1e-10),
      equilibrium_cos=float(e1@e2/(np.linalg.norm(e1)*np.linalg.norm(e2))),
      recovery_cos=float(h1@h2/(np.linalg.norm(h1)*np.linalg.norm(h2))),
      relative_signature_change_a=float(np.linalg.norm(h1-e1)/np.linalg.norm(e1)),
      relative_signature_change_b=float(np.linalg.norm(h2-e2)/np.linalg.norm(e2)),
      accuracy_equilibrium=acc_eq,accuracy_frozen_during_recovery=acc_old,
      accuracy_conditioned_during_recovery=acc_new,
      paired_accuracy_gain=acc_new-acc_old))
   print('prior',prior,'delay',delay,'scenarios',len(rows),'elapsed',round(time.time()-st,1),'s',flush=True)
 # Physical and numerical validations.
 vals=[]
 vals.append({'name':'PF voltage consistency','max_error':model.initial_max_V_err,'pass':model.initial_max_V_err<1e-10})
 vals.append({'name':'KCL algebraic residual','max_error':model.initial_KCL_err,'pass':model.initial_KCL_err<1e-10})
 vals.append({'name':'swing equilibrium residual','max_error':model.initial_max_swing_err,'pass':model.initial_max_swing_err<1e-10})
 _,x_no,y_no=model.fork(model.x0,1.,fps=fps)
 vals.append({'name':'no-event equilibrium drift','max_error':float(np.max(np.abs(x_no-model.x0))),'pass':np.max(np.abs(x_no-model.x0))<1e-8})
 xzero=model.prefix_state(7,0.,1.25)
 vals.append({'name':'prior 0 implies equilibrium','max_error':float(np.max(np.abs(xzero-model.x0))),'pass':np.max(np.abs(xzero-model.x0))<1e-8})
 xs=model.prefix_state(7,0.08,1.25)
 _,_,yplus=model.fork(xs,T,18,.001,fps);_,_,yminus=model.fork(xs,T,18,-.001,fps)
 _,_,yplus2=model.fork(xs,T,18,.0005,fps);_,_,yminus2=model.fork(xs,T,18,-.0005,fps)
 J1=(yplus-yminus)/.002;J2=(yplus2-yminus2)/.001
 e=float(np.linalg.norm(J1-J2)/np.linalg.norm(J2))
 vals.append({'name':'secondary sensitivity step-halving','relative_error':e,'pass':e<.01})
 assert all(v['pass'] for v in vals),vals
 import pandas as pd
 df=pd.DataFrame(rows);df.to_csv(OUT/'per_case.csv',index=False,float_format='%.12g')
 def summarize(groups):
  return groups.agg(n=('d2_equilibrium','size'),median_ratio_ideal=('information_ratio_ideal','median'),
   median_ratio_uncertain=('information_ratio_uncertain','median'),
   fraction_ratio_gt1_ideal=('information_ratio_ideal',lambda s:float(np.mean(s>1))),
   fraction_ratio_gt1_uncertain=('information_ratio_uncertain',lambda s:float(np.mean(s>1))),
   mean_acc_equilibrium=('accuracy_equilibrium','mean'),
   mean_acc_frozen=('accuracy_frozen_during_recovery','mean'),
   mean_acc_conditioned=('accuracy_conditioned_during_recovery','mean'),
   mean_paired_gain=('paired_accuracy_gain','mean')).reset_index()
 summary=summarize(df.groupby(['horizon_s','delay_s']))
 summary.to_csv(OUT/'by_delay.csv',index=False,float_format='%.12g')
 overall=summarize(df.groupby(['horizon_s']))
 overall.to_csv(OUT/'by_horizon.csv',index=False,float_format='%.12g')
 manifest={'config':CONFIG,'model_initial_residuals':{'KCL':model.initial_KCL_err,'swing':model.initial_max_swing_err,'V':model.initial_max_V_err},'validations':vals,'num_physical_history_groups':len(CONFIG['prior_load_buses']),'num_scenarios':len(rows),'elapsed_seconds':time.time()-st,'by_horizon':overall.to_dict(orient='records')}
 (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,default=lambda x: x.item() if isinstance(x,np.generic) else str(x)))
 print('SUMMARY:\n'+overall.to_string(index=False));print('VALIDATIONS:',len(vals),'PASS | elapsed:',round(time.time()-st,1),flush=True)
if __name__=='__main__':run()
