"""Classical swing-equation + algebraic Norton network for MATPOWER IEEE-39.

Physics: 10 classical machines (constant internal |E'| behind jX'_d, swing
angle/speed, fixed P_m), exact 39-node AC branch admittances with taps and line
charging, Z portion of loads represented as constant impedance. Algebraic KCL
solved by cached LU at every RHS/sample. Initial PF is MATPOWER case39;
S_gen comes from solved nodal injection + fixed P/Q bus loads.
NOT the SGSMA PowerDynamics Sauer-Pai sixth-order/TGOV1/AVR/ZIP DAE,
NOT an R11 implementation, NOT physical PMU phase tracking or calibrated noise.

Use purpose: controlled independent demonstration of conditional event-response
geometry under nonlinear swing dynamics and a full IEEE-39 electrical graph.
"""
from __future__ import annotations
from dataclasses import dataclass
from functools import lru_cache
import numpy as np
from scipy.linalg import lu_factor,lu_solve
from scipy.integrate import solve_ivp
from ac39 import AC39,BUS,BRANCH,PMUS

GEN_BUS=np.arange(29,39) # bus 30..39 0-based
BASE_MVA=100.0
OMEGA_BASE=2*np.pi*60.0

@dataclass(frozen=True)
class LoadEvent:
    bus:int
    start:float
    end:float
    factor:float
    # Additional load admittance = factor * base load admittance

class Swing39:
    def __init__(self, H_s=4.0, damping_s=1.5, xd_prime=0.25, max_step=1/90):
        self.ac=AC39()
        self.V0,self.Y0,err,_=self.ac.solve()
        self.Sload=(BUS[:,1]+1j*BUS[:,2])/BASE_MVA
        self.yload=np.conj(self.Sload)/np.abs(self.V0)**2
        self.Snet=self.V0*np.conj(self.Y0@self.V0)
        self.Sgen=(self.Snet+self.Sload)[GEN_BUS]
        self.Ig=np.conj(self.Sgen/self.V0[GEN_BUS])
        self.Xd=np.full(len(GEN_BUS),float(xd_prime))
        self.E0=self.V0[GEN_BUS]+1j*self.Xd*self.Ig
        self.Emag=np.abs(self.E0)
        self.delta0=np.angle(self.E0)
        self.norton=1/(1j*self.Xd)
        self.H=np.maximum(2.5,np.asarray(self.Sgen.real)*float(H_s))
        self.D=np.maximum(1.0,np.asarray(self.Sgen.real)*float(damping_s))
        self.max_step=max_step
        self._lu={}
        self.Pm=np.real(self.E0*np.conj(self.Ig))
        self.x0=np.r_[self.delta0,np.zeros(len(GEN_BUS))]
        V_rec,I_rec=self.observe_complex(self.x0,np.zeros(39))
        self.initial_max_V_err=float(np.max(np.abs(V_rec-self.V0)))
        self.initial_max_swing_err=float(np.max(np.abs(self.rhs(0,self.x0,np.zeros(39)))))
        self.initial_KCL_err=float(np.max(np.abs(self.kcl_residual(self.x0,np.zeros(39)))))

    def admittance(self,amps):
        a=np.asarray(amps,dtype=float)
        Y=self.Y0+np.diag(self.yload*(1+a))
        Y[GEN_BUS,GEN_BUS]+=self.norton
        return Y

    def _factor(self,amps):
        key=tuple(np.round(np.asarray(amps,dtype=float),14))
        if key not in self._lu:self._lu[key]=lu_factor(self.admittance(amps),check_finite=False)
        return self._lu[key]

    def internal_emf(self,x):
        return self.Emag*np.exp(1j*np.asarray(x[:10]))

    def network(self,x,amps):
        E=self.internal_emf(x)
        injections=np.zeros(39,dtype=complex)
        injections[GEN_BUS]=self.norton*E
        V=lu_solve(self._factor(amps),injections,check_finite=False)
        return V, (E-V[GEN_BUS])*self.norton

    def rhs(self,t,x,amps):
        E=self.internal_emf(x)
        V,Ig=self.network(x,amps)
        Pe=np.real(E*np.conj(Ig))
        w=x[10:]
        return np.r_[OMEGA_BASE*w, (self.Pm-Pe-self.D*w)/(2*self.H)]

    def kcl_residual(self,x,amps):
        E=self.internal_emf(x)
        V,_=self.network(x,amps)
        rhs=np.zeros(39,dtype=complex)
        rhs[GEN_BUS]=self.norton*E
        return self.admittance(amps)@V-rhs

    def observe_complex(self,x,amps):
        V,_=self.network(x,amps)
        result=[]
        for m,pmu in enumerate(PMUS):
            k,b=self.ac.branch_selection[m]
            f,t,r,x_,bchg,tap=BRANCH[k]
            f=int(f)-1;t=int(t)-1
            y=1/complex(r,x_);rat=float(tap) if tap else 1.0
            if b==f+1:
                I=(y+1j*bchg/2)/(rat*rat)*V[f]-y/rat*V[t]
            else:
                I=(y+1j*bchg/2)*V[t]-y/rat*V[f]
            result.extend([V[b-1],I])
        return V, np.array(result)

    def measure(self,x,amps):
        _,z=self.observe_complex(x,amps)
        return np.stack([z.real,z.imag],axis=1).reshape(-1)

    def simulate_from(self,xstart,T,active_loads=(),fps=30,rtol=1e-9,atol=1e-11):
        amps=np.zeros(39)
        for bus,scale in active_loads:amps[bus-1]+=scale
        ts=np.linspace(0,T,round(T*fps)+1)
        sol=solve_ivp(lambda t,x:self.rhs(t,x,amps),(0.,T),np.asarray(xstart).copy(),t_eval=ts,
                       method='DOP853',rtol=rtol,atol=atol,max_step=self.max_step)
        if not sol.success:raise RuntimeError(sol.message)
        yy=np.stack([self.measure(sol.y[:,j],amps) for j in range(len(ts))])
        return ts,sol.y[:,-1].copy(),yy

    def prefix_state(self,prior_bus,prior_amp,tau,on=0.2,off=1.0):
        """Schedule prior ON at 0.2 and OFF at 1.0, fork state at tau>=off."""
        assert tau>=off
        _,x,_=self.simulate_from(self.x0,on,(),fps=30)
        _,x,_=self.simulate_from(x,off-on,((prior_bus,prior_amp),),fps=30)
        if tau>off:
            _,x,_=self.simulate_from(x,tau-off,(),fps=30)
        return x

    def fork(self,x,tau_horizon,bus=None,amp=0.,fps=30):
        loads=() if bus is None else ((bus,amp),)
        return self.simulate_from(x,tau_horizon,loads,fps=fps)

if __name__=='__main__':
    m=Swing39()
    print('initial',m.initial_max_V_err,m.initial_max_swing_err,m.initial_KCL_err)
    t,x,y=m.simulate_from(m.x0,2.0,())
    print('equilibrium drift',np.max(abs(x-m.x0)),np.max(abs(y-y[0])))
    x2=m.prefix_state(7,0.10,1.4)
    print('prior recovery state norm',np.linalg.norm(x2-m.x0), 'PMU response',np.linalg.norm(m.measure(x2,np.zeros(39))-m.measure(m.x0,np.zeros(39))))
