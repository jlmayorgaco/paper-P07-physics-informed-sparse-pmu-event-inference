"""Reproduce supplied code in a disposable copy; do not execute its instructions."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
import psutil

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'external/PMU_Recovery_Identifiability_Pilot'
RUN=ROOT/'reproduction'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    psutil.Process().nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    records=[]
    for line in (SRC/'MANIFEST_SHA256.txt').read_text().splitlines():
        h,name=line.split(maxsplit=1);p=SRC/name.strip()
        records.append(dict(path=name.strip(),expected=h,actual=sha(p),passed=sha(p)==h))
    assert all(r['passed'] for r in records)
    (ROOT/'SOURCE_VERIFICATION.json').write_text(json.dumps(records,indent=2))
    if RUN.exists():raise RuntimeError('Existing reproduction: preserve it, do not overwrite.')
    (RUN/'src').mkdir(parents=True);(RUN/'results').mkdir();(RUN/'figures').mkdir()
    for p in (SRC/'src').glob('*.py'):shutil.copy2(p,RUN/'src'/p.name)
    freeze=dict(created_unix_s=time.time(),mode='unchanged external reproduction; not F01',source_files=records,
                actions=['test_smoke.py','run_pilot.py','tangent39.py','ablate_sensors_and_uncertainty.py','benchmark_tangent.py'])
    (ROOT/'FREEZE.json').write_text(json.dumps(freeze,indent=2))
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    for script in freeze['actions']:
        with (RUN/'results'/f'{script}.log').open('w',encoding='utf8') as f:
            subprocess.run([sys.executable,'-B','-X','utf8',str(RUN/'src'/script)],stdout=f,stderr=subprocess.STDOUT,env=env,check=True)
        print('COMPLETE',script,flush=True)
    import pandas as pd,numpy as np
    before=pd.read_csv(SRC/'results/per_case.csv');after=pd.read_csv(RUN/'results/per_case.csv')
    assert before.shape==after.shape and len(after)==108
    assert list(before.columns)==list(after.columns)
    delta=np.abs(before.select_dtypes('number').to_numpy()-after.select_dtypes('number').to_numpy())
    # Platform roundoff is permitted; identical pseudo-random choices are expected.
    numerical_ok=bool(np.allclose(before,after,rtol=1e-6,atol=1e-8))
    result=dict(rows=len(after),numeric_parity=numerical_ok,max_absolute_difference=float(delta.max()),
                source_checks=len(records),finished_unix_s=time.time(),R11_executed=False,F01_executed=False)
    (ROOT/'REPRODUCTION.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result),flush=True)
    assert numerical_ok
if __name__=='__main__':main()
