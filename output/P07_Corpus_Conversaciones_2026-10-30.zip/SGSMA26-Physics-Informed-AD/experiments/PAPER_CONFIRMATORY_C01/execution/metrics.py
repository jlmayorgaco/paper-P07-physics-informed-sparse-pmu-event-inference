"""Pure metric functions; no estimator parameters or C01 data are imported."""
import numpy as np
NUMBER={'normal':0,'line':2,'load':4}
def alarms(meta):
    result=[]
    for a in [x for x in meta.get('events',[]) if x['kind']=='alarm']:
        d=next((x for x in meta['events'] if x['episode']==a['episode'] and x['kind']=='diagnosis'),None)
        result.append(dict(episode=a['episode'],alarm_s=a['emitted_s'],emitted_s=d['emitted_s'] if d else np.nan,family=d.get('family') if d else None,source=d.get('source') if d else 'ABSTAIN',top3=d.get('top3',[]) if d else [],estimated_onset_s=d.get('onset_s',np.nan) if d else np.nan))
    return result
def labels(t,meta):
    y=np.zeros(len(t),int)
    if not meta.get('available',True):return np.full(len(t),-1)
    for a in [x for x in meta.get('events',[]) if x['kind']=='alarm']:
        stop=next((e for e in meta['events'] if e['episode']==a['episode'] and e['kind'] in ['restoration','withdrawn','superseded','right_censored']),None)
        end=stop['emitted_s'] if stop and stop['kind']!='right_censored' else t[-1]+1/30
        ix=(t>=a['emitted_s']-1e-9)&(t<end-1e-9);y[ix]=8
        d=next((e for e in meta['events'] if e['episode']==a['episode'] and e['kind']=='diagnosis'),None)
        if d:y[ix&(t>=d['emitted_s']-1e-9)]=NUMBER.get(d['family'],8)
    return y
def match(truth,aa,horizon):
    """Same temporal greedy rule as H04: earliest unmatched alarm, 30s cap.
    No association using true family/source. Null OFF means right censoring.
    """
    used=set();rows=[]
    for j,e in enumerate(truth):
        end=e['off_s'] if e['off_s'] is not None else horizon+1/30
        bound=min(e['onset_s']+30,truth[j+1]['onset_s'] if j+1<len(truth) else horizon+1e-8)
        choices=[i for i,a in enumerate(aa) if i not in used and e['onset_s']<=a['alarm_s']<bound]
        ix=choices[0] if choices else None;a=aa[ix] if ix is not None else {};det=bool(a)
        if ix is not None:used.add(ix)
        correct=bool(det and a.get('family')==e['family'] and a.get('source')==e['source'])
        rows.append(dict(event=e['id'],family=e['family'],source=e['source'],onset_s=e['onset_s'],off_s=e['off_s'],detected=det,joint=correct,timely=bool(correct and a['emitted_s']<end),top3=bool(det and a.get('family')==e['family'] and e['source'] in a.get('top3',[])),alarm_s=a.get('alarm_s',np.nan),emitted_s=a.get('emitted_s',np.nan),delay_s=a.get('alarm_s',np.nan)-e['onset_s'],diagnosis_delay_s=a.get('emitted_s',np.nan)-e['onset_s'],onset_error_s=a.get('estimated_onset_s',np.nan)-e['onset_s'],episode=a.get('episode')))
    extras=[a for i,a in enumerate(aa) if i not in used]
    return rows,extras
def first_stop(truth,aa,horizon,available=True):
    e=truth[0];a=aa[0] if aa and available else {};pre=bool(a and a['alarm_s']<e['onset_s'])
    correct=bool(a and not pre and a.get('family')=='line' and a.get('source')==e['source'] and a['emitted_s']<=horizon)
    return dict(source=e['source'],onset_s=e['onset_s'],first_alarm_s=a.get('alarm_s',np.nan),first_emitted_s=a.get('emitted_s',np.nan),prechange_alarm=pre,first_correct=correct,first_stopped=bool(a),right_censored=not bool(a),delay_s=a['alarm_s']-e['onset_s'] if a and not pre else np.nan,restricted_correct_delay_s=a['emitted_s']-e['onset_s'] if correct else horizon-e['onset_s'])
def report_counts(t,truth,meta):
    yt=np.zeros(len(t),int)
    for e in truth:yt[(t>=e['onset_s'])&(t<(e['off_s'] if e['off_s'] is not None else t[-1]+1/30))]=NUMBER[e['family']]
    yp=labels(t,meta);use=t>=12.;a=yt[use]>0;b=yp[use]>0
    # Positive abstentions are FN. Normal abstentions are retained separately.
    return dict(tp=int((a&b).sum()),fp=int((~a&b).sum()),fn=int((a&~b).sum()),abstentions=int((yp[use]<0).sum()),monitored_reports=int(use.sum()))
def bootstrap_difference(left,right,metric,rng,repetitions=10000):
    """Inputs are paired parent aggregates (numerator,denominator)."""
    left=np.asarray(left,float);right=np.asarray(right,float)
    if left.shape!=right.shape or not len(left):raise ValueError('Paired parents required')
    idx=rng.integers(len(left),size=(repetitions,len(left)));a=left[idx].sum(axis=1);b=right[idx].sum(axis=1)
    if metric=='f1':
        f=lambda x:np.divide(2*x[:,0],2*x[:,0]+x[:,1]+x[:,2],out=np.zeros(len(x)),where=(2*x[:,0]+x[:,1]+x[:,2])>0)
    else:f=lambda x:np.divide(x[:,0],x[:,1],out=np.full(len(x),np.nan),where=x[:,1]>0)
    point=float(f(left.sum(axis=0,keepdims=True))[0]-f(right.sum(axis=0,keepdims=True))[0]);v=f(a)-f(b)
    return point,*np.nanquantile(v,[.025,.975]).tolist()
