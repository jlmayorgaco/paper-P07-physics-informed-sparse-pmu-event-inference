"""C01 confirmatory evaluation. Seal predictions before opening private truth."""
import json,sys
import numpy as np
import pandas as pd
from common import *
from metrics import alarms,match,first_stop,report_counts,bootstrap_difference
OUT=RUN/'results'
def seal_predictions():
    public=read(DATA/'INPUTS.json');paths=[DATA/'INPUTS.json']
    for r in public:
        for a in ARMS:
            folder=DATA/'predictions'/r['id']/a;meta=folder/'prediction.json';failed=RUN/'failures'/f"{r['id']}_{a}.json"
            if not meta.exists() and not failed.exists():raise RuntimeError(f'Unaccounted inference {r["id"]}/{a}')
            paths+=list(folder.glob('*'))
    paths+=list((RUN/'failures').glob('*.json'))
    value=dict(before_truth_read=True,execution_freeze_sha256=sha(ROOT/'protocol/EXECUTION_FREEZE.json'),files=[dict(path=p.relative_to(REPO).as_posix(),sha256=sha(p)) for p in paths if p.is_file()])
    dest=OUT/'PREDICTIONS_SEAL.json'
    if dest.exists():assert read(dest)==value
    else:save(dest,value)
def main():
    OUT.mkdir(parents=True,exist_ok=True);seal_predictions()
    # This is the first private-truth read by the evaluator.
    cases=read(DATA/'truth_private/cases.json');replays=read(DATA/'truth_private/replays.json');request=read(ENGINE/'events/protocol.json');by_case={c['id']:c for c in request['cases']}
    replay_map={(r['physical_id'],r['noise_std_factor'],r['seed']):r for r in replays};rows=[];ee=[];xx=[];pp=[]
    for c in cases:
        spec=by_case[c['id']]
        for noise in spec['noise_factors']:
            for seed in spec['noise_seeds']:
                r=replay_map.get((c['id'],noise,seed));rid=r['id'] if r else f"UNAVAILABLE_{c['id']}_{noise}"
                t=np.arange(round(c['duration_s']*30)+1)/30
                for arm in ARMS:
                    ctx=dict(method=arm,record=rid,parent=c['parent_schedule'],condition=c['condition'],noise=noise,lane=c['lane'],duration_s=c['duration_s'])
                    folder=DATA/'predictions'/rid/arm;failed=RUN/'failures'/f'{rid}_{arm}.json';available=bool(r and (folder/'prediction.json').exists() and not failed.exists())
                    meta=read(folder/'prediction.json') if available else dict(available=False,truth_read=False,events=[])
                    assert not meta.get('truth_read',False)
                    if available:
                        digest=meta.get('observation_sha256',meta.get('input_sha256'));assert digest==r['sha256']
                    if arm=='CHEN2016':
                        d=meta.get('decision');aa=[dict(episode=1,alarm_s=d['time_s'],emitted_s=d['time_s'],family='line',source=d['source'],top3=[d['source']])] if d else []
                    else:aa=alarms(meta)
                    matched,extra=match(c['events'],aa,c['duration_s']);matched_ep={v['episode'] for v in matched if v['detected']};rests={z['episode']:z for z in meta.get('events',[]) if z['kind']=='restoration'}
                    for event in matched:
                        rest=rests.get(event['episode']);event.update(ctx);event['off_delay_s']=rest['emitted_s']-event['off_s'] if rest and event['off_s'] is not None else np.nan;event['available']=available;ee.append(event)
                    for a in extra:xx.append(dict(**ctx,alarm_s=a['alarm_s'],pred_source=a['source'],normal_control=not c['events']))
                    start=10. if arm=='CHEN2016' else 12.;normal_exposure=max(0,c['duration_s']-start) if available and not c['events'] else 0.
                    if arm=='CHEN2016' and normal_exposure and aa:normal_exposure=max(0.,aa[0]['alarm_s']-start)
                    counts=report_counts(t,c['events'],meta) if arm!='CHEN2016' else dict(tp=0,fp=0,fn=0,abstentions=0,monitored_reports=0)
                    rows.append(dict(**ctx,available=available,physical_available=r is not None,events=len(matched),detected=sum(v['detected'] for v in matched),timely=sum(v['timely'] for v in matched),joint=sum(v['joint'] for v in matched),top3=sum(v['top3'] for v in matched),extras=len(extra),alarms=len(aa),normal_FA=len(aa) if not c['events'] else 0,normal_any_alarm=bool(aa) if not c['events'] else False,normal_available_s=normal_exposure,normal_planned_s=max(0,c['duration_s']-start) if not c['events'] else 0,monitored_s=max(0,c['duration_s']-start) if available else 0,false_restorations=sum(ep not in matched_ep for ep in rests),open_eof=sum(z['kind']=='right_censored' for z in meta.get('events',[])),**counts))
                    if c['lane']=='persistent_line':pp.append(dict(**ctx,available=available,**first_stop(c['events'],aa,c['duration_s'],available)))
    rd=pd.DataFrame(rows);ed=pd.DataFrame(ee);xd=pd.DataFrame(xx,columns=['method','record','parent','condition','noise','lane','duration_s','alarm_s','pred_source','normal_control']);pdets=pd.DataFrame(pp)
    for n,d in [('RECORDS',rd),('EVENTS',ed),('EXTRAS',xd),('PERSISTENT_FIRST_STOP',pdets)]:d.to_csv(OUT/(n+'.csv'),index=False)
    assert len(rd)==342*len(ARMS),('All intended records must be retained',len(rd))
    summary=[]
    for lane in ['continuous','persistent_line']:
        for (arm,condition,noise),g in rd[rd.lane.isin([lane,'normal'])].groupby(['method','condition','noise']):
            if lane=='continuous' and arm=='CHEN2016':continue
            ev=g[g.lane==lane];norm=g[g.lane=='normal'];sub=ed[(ed.method==arm)&(ed.condition==condition)&(ed.noise==noise)&(ed.lane==lane)];nf=int(norm.normal_FA.sum());expo=norm.normal_available_s.sum();tp,fp,fn=[int(g[k].sum()) for k in ['tp','fp','fn']]
            psub=pdets[(pdets.method==arm)&(pdets.condition==condition)&(pdets.noise==noise)]
            summary.append(dict(lane=lane,method=arm,condition=condition,noise=noise,intended_records=len(g),available_records=int(g.available.sum()),event_parents=ev.parent.nunique(),normal_parents=norm.parent.nunique(),events=int(ev.events.sum()),timely=int(ev.timely.sum()),joint=int(ev.joint.sum()),top3=int(ev.top3.sum()),event_extras=int(ev.extras.sum()),extras_per_event_hour=float(ev.extras.sum()/ev.duration_s.sum()*3600),normal_FA=nf,normal_records_with_alarm=int(norm.normal_any_alarm.sum()),normal_available_s=expo,normal_planned_s=norm.normal_planned_s.sum(),normal_FA_hour=nf*3600/expo if expo else np.nan,zero_alarm_Poisson_upper95_hour=-np.log(.05)*3600/expo if expo and nf==0 else np.nan,detection_f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn and arm!='CHEN2016' else np.nan,median_diagnosis_delay_s=sub.diagnosis_delay_s.median(),median_restoration_delay_s=sub.off_delay_s.median(),false_restorations=int(ev.false_restorations.sum()),open_eof=int(ev.open_eof.sum()),abstained_reports=int(g.abstentions.sum()),first_correct=int(psub.first_correct.sum()) if lane=='persistent_line' else np.nan,first_prechange=int(psub.prechange_alarm.sum()) if lane=='persistent_line' else np.nan,first_right_censored=int(psub.right_censored.sum()) if lane=='persistent_line' else np.nan,mean_restricted_correct_delay_s=psub.restricted_correct_delay_s.mean() if lane=='persistent_line' else np.nan))
    sd=pd.DataFrame(summary);sd.to_csv(OUT/'SUMMARY.csv',index=False)
    plan=read(ROOT/'protocol/PLAN.json');rng=np.random.default_rng(plan['bootstrap_seed']);paired=[]
    for lane in ['continuous','persistent_line']:
        for (condition,noise),group in rd[rd.lane.isin([lane,'normal'])].groupby(['condition','noise']):
            for method in ['R11','R11_NOMINAL']:
                for reference in ['ET_REFERENCE','ET_CANDIDATE']+(['CHEN2016'] if lane=='persistent_line' else []):
                    aa=group[group.method==method].set_index('parent').sort_index();bb=group[group.method==reference].set_index('parent').sort_index();assert aa.index.equals(bb.index)
                    specs=[('timely_fraction',['timely','events'],'ratio'),('extras_per_event_hour',['extras','duration_s'],'ratio'),('report_detection_f1',['tp','fp','fn'],'f1')]
                    if lane=='persistent_line':
                        aa=aa.join(pdets[(pdets.method==method)&(pdets.condition==condition)&(pdets.noise==noise)].set_index('parent')[['first_correct']],how='left');bb=bb.join(pdets[(pdets.method==reference)&(pdets.condition==condition)&(pdets.noise==noise)].set_index('parent')[['first_correct']],how='left');aa['one_event']=(aa.lane==lane).astype(int);bb['one_event']=(bb.lane==lane).astype(int);aa['first_correct']=aa.first_correct.fillna(False).astype(int);bb['first_correct']=bb.first_correct.fillna(False).astype(int);specs=[('first_correct_fraction',['first_correct','one_event'],'ratio')]
                    for metric,columns,kind in specs:
                        a,b=aa[columns].to_numpy(float),bb[columns].to_numpy(float)
                        if metric=='extras_per_event_hour':
                            mask=aa.lane==lane;a=a[mask];b=b[mask];a[:,0]*=3600;b[:,0]*=3600
                        point,lo,hi=bootstrap_difference(a,b,kind,rng,plan['bootstrap_replicates']);paired.append(dict(lane=lane,condition=condition,noise=noise,method=method,reference=reference,metric=metric,difference=point,lower95=lo,upper95=hi,parents=len(a),resampling_unit='physical_parent'))
    pd.DataFrame(paired).to_csv(OUT/'PAIRED_INTERVALS.csv',index=False)
    ed.groupby(['lane','method','condition','noise','family','source']).agg(events=('event','size'),timely=('timely','sum'),joint=('joint','sum')).to_csv(OUT/'BY_SOURCE.csv')
    save(OUT/'EVALUATION_AUDIT.json',dict(complete_intended_records=True,intended_observed_records=342,records_per_method=len(rd)//len(ARMS),physical_rejections=read(DATA/'checks/PHYSICAL_REJECTIONS.json'),inference_failures=[read(p) for p in (RUN/'failures').glob('*.json')],prediction_sealed_before_truth=True,source_scope='known nine load / nine line catalog',method_retuned=False,RAW0002_opened=False,official_hackathon_score=False,bootstrap='10000 paired parent-cluster replicates',Chen_normal_exposure='Until first stop or horizon; R11/ML monitor full records. Compare normal-record alarm incidence as well as native exposure rates.',no_superiority_selection=True))
    print(sd.to_string(index=False))
if __name__=='__main__':main()
