"""Completed C01 outputs -> archived evidence, scientific graphics and P07.
Executed only after full intended-case evaluation. Never changes estimators.
"""
import hashlib,json,shutil,subprocess
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from common import *
PAPER=REPO.parent/'paper-P07-physics-informed-sparse-pmu-event-inference'
NAMES={'R11':'R11 mixture','R11_NOMINAL':'R11 nominal','ET_REFERENCE':'ExtraTrees','ET_CANDIDATE':'ET short','CHEN2016':'Chen2016'}
COLORS=['#0072b2','#009e73','#777777','#aaaaaa','#d55e00']
def figures(summary,intervals,target):
    target.mkdir(parents=True,exist_ok=True);plt.rcParams.update({'font.size':8,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    for lane,field,name in [('continuous','timely','c01_continuous'),('persistent_line','first_correct','c01_persistent')]:
        arms=ARMS[:4] if lane=='continuous' else ARMS;fig,axes=plt.subplots(2,3,figsize=(7.2,4.4),sharey=True,layout='constrained')
        for row,noise in enumerate([1.,2.]):
            for col,condition in enumerate(['MATCH','RX_IN_SUPPORT','RX_OUT_SUPPORT']):
                ax=axes[row,col];g=summary[(summary.lane==lane)&(summary.condition==condition)&(summary.noise==noise)].set_index('method');x=np.arange(len(arms));v=np.array([g.loc[a,field]/g.loc[a,'events'] for a in arms]);ax.bar(x,v,color=COLORS[:len(arms)])
                ax.set_xticks(x,[NAMES[a] for a in arms],rotation=45,ha='right');ax.set_ylim(0,1.13);ax.set_title(condition.replace('RX_','')+f'; noise x{noise:g}');ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
                for k,a in enumerate(arms):ax.text(k,v[k]+.02,f'{int(g.loc[a,field])}/{int(g.loc[a,"events"])}',ha='center',fontsize=7)
        axes[0,0].set_ylabel('Correct timely fraction' if lane=='continuous' else 'Correct first-stop fraction');axes[1,0].set_ylabel('Fraction');fig.savefig(target/(name+'.pdf'));fig.savefig(target/(name+'.png'),dpi=200);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.1,3.1),layout='constrained');d=intervals[(intervals.lane=='continuous')&(intervals.metric=='timely_fraction')&(intervals.reference=='ET_REFERENCE')].copy();d['label']=d.condition.str.replace('RX_','')+' / noise x'+d.noise.map(lambda n:f'{n:g}')+' / '+d.method.map(NAMES);d=d.sort_values(['condition','noise','method']);y=np.arange(len(d));v=d.difference.to_numpy()*100;ax.errorbar(v,y,xerr=np.vstack([v-d.lower95.to_numpy()*100,d.upper95.to_numpy()*100-v]),fmt='o',markersize=4,capsize=2,color='#0072b2');ax.axvline(0,color='#555',lw=1);ax.set_yticks(y,d.label);ax.set_xlabel('Timely family/source difference vs ExtraTrees (percentage points)');ax.grid(axis='x',alpha=.15);fig.savefig(target/'c01_paired_intervals.pdf');fig.savefig(target/'c01_paired_intervals.png',dpi=200);plt.close(fig)
def table(summary,lane,path):
    arms=ARMS[:4] if lane=='continuous' else ARMS;field='timely' if lane=='continuous' else 'first_correct'
    text=[r'\begin{table*}[t]\centering\small',r'\caption{C01 '+('continuous timely family/source decisions before OFF' if lane=='continuous' else 'persistent-line correct first stopping decisions')+r'. Rows retain paired conditions/noise. Each normal control is shared across the two eligible evaluation lanes; it is not an additional independent record. Failed intended cases remain in event denominators.}',r'\label{tab:c01-'+lane.replace('_','-')+'}',r'\begin{tabular}{ll'+'r'*len(arms)+'}',r'\toprule','Condition & Noise & '+' & '.join(NAMES[a] for a in arms)+r'\\\midrule']
    for (condition,noise),g in summary[summary.lane==lane].groupby(['condition','noise']):
        g=g.set_index('method');text.append(condition.replace('_',r'\_')+f' & {noise:g} & '+' & '.join(f'{int(g.loc[a,field])}/{int(g.loc[a,"events"])}' for a in arms)+r'\\')
    text += [r'\bottomrule\end{tabular}\end{table*}'];path.write_text('\n'.join(text)+'\n',encoding='utf-8')
def main():
    result=RUN/'results';audit=read(result/'EVALUATION_AUDIT.json');assert audit['complete_intended_records'];summary=pd.read_csv(result/'SUMMARY.csv');intervals=pd.read_csv(result/'PAIRED_INTERVALS.csv')
    archive=PAPER/'generated/frozen/c01_20261029';archive.mkdir(parents=True,exist_ok=True);manifest=[]
    for p in list(result.glob('*'))+[ROOT/'protocol/PLAN.json',ROOT/'protocol/FREEZE.json',ROOT/'protocol/EXECUTION_FREEZE.json',ROOT/'execution_request/REQUEST.json']:
        if not p.is_file():continue
        target=archive/p.name
        if target.exists() and sha(target)!=sha(p):raise RuntimeError('Refusing to replace imported evidence: '+str(target))
        shutil.copy2(p,target);manifest.append(dict(path=target.name,sha256=sha(p),source=p.relative_to(REPO).as_posix()))
    save(archive/'MANIFEST.json',dict(status='CONFIRMATORY_EXECUTED_NO_RETUNING',files=manifest))
    figures(summary,intervals,PAPER/'figures/generated')
    for lane in ['continuous','persistent_line']:table(summary,lane,PAPER/'tables/generated'/('c01_'+lane+'.tex'))
    macros=[]
    for arm,prefix in [('R11','COneMix'),('R11_NOMINAL','COneNom'),('ET_REFERENCE','COneET')]:
        g=summary[(summary.method==arm)&(summary.lane=='continuous')]
        for name,value in [('Timely',int(g.timely.sum())),('Total',int(g.events.sum())),('Extras',int(g.event_extras.sum()))]:macros.append('\\newcommand{\\'+prefix+name+'}{'+str(value)+'}')
    (PAPER/'generated/c01_macros.tex').write_text('\n'.join(macros)+'\n',encoding='utf-8')
    section=r'''\subsection{Confirmatory Continuous and Persistent-Line Comparison}
\label{sec:c01-results}
The C01 campaign was executed with both R11 references, both ExtraTrees artifacts,
and the declared Chen2016 adapter fixed before predictions. It contains 18
continuous parents with six interventions each, 27 persistent-line parents, and
12 normal parents. Three fixed R/X conditions and two instrumental-noise scales
produce 171 intended physical trajectories and 342 intended observed records.
Replays and conditions are paired; they are not independent samples.

\input{tables/generated/c01_continuous}
\input{tables/generated/c01_persistent_line}
Across the six continuous strata, R11 obtains \COneMixTimely{}/\COneMixTotal{}
timely joint decisions with \COneMixExtras{} event-stream extras; the nominal
reference obtains \COneNomTimely{}/\COneNomTotal{} with \COneNomExtras{} extras.
ExtraTrees reference obtains \COneETTimely{}/\COneETTotal{} with
\COneETExtras{} extras. These totals describe paired realizations of 108
interventions, not that many independent events. Figures~\ref{fig:c01-main}
and~\ref{fig:c01-ci} show stratified outcomes and parent-cluster paired intervals.
No new method is selected or adjusted using these outcomes.

\begin{figure*}[t]\centering
\includegraphics[width=.96\textwidth]{figures/generated/c01_continuous.pdf}
\caption{C01 continuous results with frozen methods. Every stratum retains its
intended event denominator, including unavailable predictions.}
\label{fig:c01-main}\end{figure*}
\begin{figure*}[t]\centering
\includegraphics[width=.94\textwidth]{figures/generated/c01_paired_intervals.pdf}
\caption{Paired timely-attribution differences and percentile 95\% intervals
from 10,000 resamples of physical parents. Correlated frames, conditions and
noise replays are not counted as additional independent trials. Intervals are
descriptive finite-sample uncertainty, not a universal superiority guarantee.}
\label{fig:c01-ci}\end{figure*}

The persistent-line lane compares the first stopping decision, retaining
pre-change stops, wrong sources, omitted detections and horizon censoring.
Chen2016 processes nonoverlapping increments at 15 Hz from the common 30-fps
stream and has no restoration or load output. Its normal exposure ends at its
first stop; R11 and ML retain their full monitoring intervals. The archived
tables provide both normal-record alarm incidence and the corresponding native
exposure. A normal-exposure rate is not advertised as an ARL theorem under
colored F01 noise. The zero-alarm Poisson bound is reported only where applicable
and with that modeling qualification.

The result is confined to the known load/line catalog, F01 operation and the
declared perturbation/noise ranges. It does not establish a new hackathon
leaderboard score, all-family diagnosis, changing PMU sets, source-excluded
transfer, calibrated probabilities or field validation. A complete failure
ledger and all intended denominators accompany the frozen CSV outputs.
'''
    (PAPER/'sections/08c_c01_confirmatory.tex').write_text(section,encoding='utf-8')
    p=PAPER/'main.tex';s=p.read_text(encoding='utf-8')
    if '\\input{generated/c01_macros}' not in s:s=s.replace('\\input{generated/continuous_macros}','\\input{generated/continuous_macros}\n\\input{generated/c01_macros}')
    if '\\input{sections/08c_c01_confirmatory}' not in s:s=s.replace('\\input{sections/09_discussion}','\\input{sections/08c_c01_confirmatory}\n\\input{sections/09_discussion}')
    s=s.replace('while its common confirmatory comparison remains pending','with its common confirmatory comparison reported separately');p.write_text(s,encoding='utf-8')
    # Retain H04 as historical development evidence; update only stale status.
    p=PAPER/'sections/08b_continuous_evidence.tex';s=p.read_text(encoding='utf-8');s=s.replace('C01 has not been executed; it contributes no performance number to this manuscript.','C01 was subsequently executed without method changes; its distinct confirmatory outcomes appear in Section~\\ref{sec:c01-results}.');p.write_text(s,encoding='utf-8')
    for name in ['sections/09_discussion.tex','sections/10_conclusion.tex']:
        p=PAPER/name;s=p.read_text(encoding='utf-8');s=s.replace('The next decision is a finite confirmatory comparison, not another bus-specific repair.','The subsequent finite confirmatory comparison retains both fixed references without another bus-specific repair.');s=s.replace('No confirmatory outcome is claimed before execution.','The confirmatory outcomes and failure ledger are reported separately in Section~\\ref{sec:c01-results}.');p.write_text(s,encoding='utf-8')
    report='# C01 executed without retuning\n\n'+summary.to_csv(index=False)+'\n\nAll intended failures/censoring retained. Publication readiness still requires claim/citation/reproducibility and coauthor review. No all-family or field claim.\n'
    (PAPER/'docs/c01-confirmatory-results.md').write_text(report,encoding='utf-8');(ROOT/'CONFIRMATORY_RESULTS.md').write_text(report,encoding='utf-8')
    for name in ['PAPER_PLAN.md','README.md','TODO_PENDING.md']:
        p=PAPER/name;s=p.read_text(encoding='utf-8');s='> C01 execution update: completed without retuning; see [results and failure ledger](docs/c01-confirmatory-results.md). Earlier pending statements below are historical; final scientific/editorial review remains open.\n\n'+s;p.write_text(s,encoding='utf-8')
    with (RUN/'logs/paper_build.log').open('w',encoding='utf-8') as f:subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(PAPER/'scripts/build_manuscript_bundle.ps1')],cwd=PAPER,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
    save(RUN/'PAPER_UPDATED.json',dict(paper=str(PAPER),outputs_imported=True,figures_generated=True,PDF_compiled=True,submission_authorized=False))
if __name__=='__main__':main()
