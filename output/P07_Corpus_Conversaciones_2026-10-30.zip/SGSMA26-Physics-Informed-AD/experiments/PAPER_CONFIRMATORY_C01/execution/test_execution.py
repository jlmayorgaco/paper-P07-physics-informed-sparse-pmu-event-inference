"""Pre-outcome evaluator tests: early/wrong/late, censoring, failures, pairing."""
import json
import numpy as np
from metrics import *
from common import ROOT,save
truth=[dict(id='e1',family='load',source='BUS7',onset_s=20.,off_s=23.,amplitude=.1),dict(id='e2',family='line',source='LINE3-4',onset_s=26.,off_s=29.,amplitude=None)]
def a(t,source,family='load',emit=None):return dict(episode=int(t),alarm_s=t,emitted_s=t if emit is None else emit,family=family,source=source,top3=[source])
rows,extra=match(truth,[a(19.,'BUS7'),a(20.2,'BUS16'),a(20.3,'BUS7'),a(26.2,'LINE3-4','line')],40.)
assert not rows[0]['joint'] and rows[1]['timely'] and len(extra)==2
rows,_=match(truth,[a(22.,'BUS7',emit=23.2)],40.);assert rows[0]['joint'] and not rows[0]['timely']
persist=[dict(id='p',family='line',source='LINE3-4',onset_s=20.,off_s=None,amplitude=None)]
assert first_stop(persist,[a(19.,'LINE3-4','line'),a(21.,'LINE3-4','line')],60.)['prechange_alarm']
assert not first_stop(persist,[a(19.,'LINE3-4','line'),a(21.,'LINE3-4','line')],60.)['first_correct']
assert first_stop(persist,[a(21.,'LINE3-4','line')],60.)['first_correct']
f=first_stop(persist,[],60.,False);assert f['right_censored'] and f['restricted_correct_delay_s']==40
t=np.arange(1201)/30;rc=report_counts(t,truth,dict(available=False));assert rc['fn']>0 and rc['abstentions']==841
x=np.array([[2,3],[1,3],[3,3]],float);d,lo,hi=bootstrap_difference(x,x,'ratio',np.random.default_rng(1));assert d==lo==hi==0
# Shared physical parent is a single row; duplicate noise realizations must be
# aggregated by parent before bootstrap, not bootstrapped as separate rows.
assert bootstrap_difference([[4,6],[2,6]],[[2,6],[2,6]],'ratio',np.random.default_rng(1))[0]>0
save(ROOT/'checks/EXECUTION_TESTS.json',dict(passed=True,earliest_temporal_matching=True,wrong_source_not_oracle_matched=True,late_diagnosis_penalized=True,null_off_censored=True,persistent_first_stop_not_best_stop=True,missing_inference_retains_FN=True,parent_paired_bootstrap=True))
print('C01_EXECUTION_TESTS_PASS')
