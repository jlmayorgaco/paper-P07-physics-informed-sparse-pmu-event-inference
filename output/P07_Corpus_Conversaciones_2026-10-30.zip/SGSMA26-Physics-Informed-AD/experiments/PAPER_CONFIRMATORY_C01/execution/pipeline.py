"""Resumable C01 executor. One physical and one inference process, sequential.
No fitting on test events. Existing frozen sources are never edited.
"""
from datetime import datetime,timezone
import argparse,shutil,sys,traceback
from common import *
HERE=Path(__file__).resolve().parent
def verify():
    sys.path.insert(0,str(ROOT/'protocol'));import campaign
    campaign.verify()
    seal=read(ROOT/'protocol/EXECUTION_FREEZE.json')
    for f in seal['files']:
        if sha(REPO/f['path'])!=f['sha256']:raise RuntimeError('Execution code changed: '+f['path'])
def seal():
    target=ROOT/'protocol/EXECUTION_FREEZE.json'
    if target.exists():raise FileExistsError(target)
    sys.path.insert(0,str(ROOT/'protocol'));import campaign;campaign.verify()
    paths=list(HERE.glob('*.py'))+[ROOT/'protocol/FREEZE.json',ROOT/'execution_request/REQUEST.json',ROOT/'execution_request/simulator/events/protocol.json',ROOT/'execution_request/truth_private/cases.json']
    save(target,dict(utc=datetime.now(timezone.utc).isoformat(),before_C01_predictions=True,before_C01_physics=True,configuration_already_drawn=True,method_or_protocol_changes=False,files=[dict(path=p.relative_to(REPO).as_posix(),sha256=sha(p)) for p in paths]))
def stage():
    verify()
    if (RUN/'STAGED.json').exists():return
    RUN.mkdir(parents=True,exist_ok=True)
    if not RUNTIME.exists():shutil.copytree(H04/'runtime',RUNTIME,ignore=shutil.ignore_patterns('development','__pycache__','*.pyc'))
    for n in ['reference','environment']:
        if not (ENGINE/n).exists():shutil.copytree(H04/'engine'/n,ENGINE/n,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    for n in ['nominal_engine.jl','generator_mismatch.jl','export_pmu.py']:shutil.copy2(H04/'engine'/n,ENGINE/n)
    for n in ['diagnostics','operating_points','events/diagnostics','events/results']:(ENGINE/n).mkdir(parents=True,exist_ok=True)
    shutil.copy2(ROOT/'execution_request/simulator/events/protocol.json',ENGINE/'events/protocol.json')
    for n in ['observed','observations','truth_private','checks','predictions']:(DATA/n).mkdir(parents=True,exist_ok=True)
    shutil.copy2(ROOT/'execution_request/truth_private/cases.json',DATA/'truth_private/cases.json')
    shutil.copy2(REPO/'SIM0018_BOUNDARY_HOLDOUT/export_campaign.py',DATA/'export_campaign.py')
    # Public exporter wrapper, only paths rebound; original reporting/noise code.
    (DATA/'prepare_campaign.py').write_text(f"from pathlib import Path\nimport json,hashlib\nROOT=Path({str(DATA)!r})\nREPO=Path({str(REPO)!r})\nMETHOD=Path({str(RUNTIME)!r})\nENGINE=Path({str(ENGINE)!r})\ndef sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()\ndef save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2),encoding='utf-8')\n",encoding='utf-8')
    save(RUN/'STAGED.json',dict(source_runtime=str(H04/'runtime'),frozen_sources_edited=False,execution_freeze_sha256=sha(ROOT/'protocol/EXECUTION_FREEZE.json')))
def worker(mode,rid):return call(mode+'_'+rid,[sys.executable,'-B','-X','utf8',HERE/'worker.py',mode,'--record',rid],check=False)
def failure(rid,arm,stage):save(RUN/'failures'/f'{rid}_{arm}.json',dict(record=rid,method=arm,stage=stage,status='UNAVAILABLE_INTENDED_CASE_RETAINED'))
def run():
    stage();verify()
    if not (RUN/'PHYSICS_COMPLETE.json').exists():
        call('physics',['julia','--startup-file=no','--threads=1','--project='+str(ENGINE/'environment'),ENGINE/'generator_mismatch.jl'])
        save(RUN/'PHYSICS_COMPLETE.json',dict(complete=True))
    if not (DATA/'INPUTS.json').exists():call('export',[sys.executable,'-B','-X','utf8',DATA/'export_campaign.py'])
    records=read(DATA/'INPUTS.json');ready=[]
    # No truth opened below: only public records and their prefixes.
    for r in records:
        rid=r['id']
        if not (RUN/'prefix'/rid/'COMPLETE.json').exists() and worker('prefix',rid):
            for arm in ['R11','R11_NOMINAL']:failure(rid,arm,'prefix')
        if (RUN/'prefix'/rid/'COMPLETE.json').exists():ready.append(r)
        if not (RUN/'ml_prefix'/rid/'COMPLETE.json').exists() and worker('mlprefix',rid):
            for arm in ['ET_REFERENCE','ET_CANDIDATE']:failure(rid,arm,'prefix')
    if not (RUN/'DERIVATIVES_COMPLETE.json').exists():
        points=[dict(id=r['id'],factors_by_particle={k:v['physical']['factors'] for k,v in read(RUN/'prefix'/r['id']/'fits.json').items()}) for r in ready]
        req=RUN/'DERIVATIVES_REQUEST.json';save(req,dict(output=str(RUN/'derivatives'),points=points,resume=True))
        # Original builder writes only to request.output. Per-record bank errors
        # remain visible; a global Julia failure is a real execution blocker.
        command=['julia','--startup-file=no','--threads=1','--project='+str(RUNTIME/'model/physics/environment'),PHYSICS/'build_static_rx.jl']
        rc=call('derivatives',command+[req],check=False)
        if rc:
            # A failing point cannot erase every later intended record.
            # Resume checked complete points; isolate unfinished points without
            # changing any builder equation, tolerances or parameter support.
            ids=read(PHYSICS/'ENSEMBLE.json')['particles']
            for point in points:
                rid=point['id']
                if all((RUN/'derivatives/grid'/rid/p['id']/'CHECK.json').exists() for p in ids):continue
                one=RUN/'derivative_requests'/(rid+'.json');save(one,dict(output=str(RUN/'derivatives'),points=[point],resume=True))
                if call('derivatives_'+rid,command+[one],check=False):
                    for arm in ['R11','R11_NOMINAL']:failure(rid,arm,'derivatives')
        save(RUN/'DERIVATIVES_COMPLETE.json',dict(records=len(ready)))
    for r in records:
        rid=r['id'];dest=DATA/'predictions'/rid
        # Prevent disk exhaustion without deleting baselines or prior attempts.
        if shutil.disk_usage(RUN).free<10*2**30:raise OSError('Less than 10 GiB free; execution paused for storage, no case discarded')
        if (RUN/'prefix'/rid/'COMPLETE.json').exists() and not (RUN/'failures'/f'{rid}_R11.json').exists():
            if not (RUN/'particles'/rid/'COMPLETE.json').exists() and worker('bank',rid):
                for arm in ['R11','R11_NOMINAL']:failure(rid,arm,'bank')
            if (RUN/'particles'/rid/'COMPLETE.json').exists() and not (dest/'COMPLETE.json').exists():
                if worker('r11',rid):
                    for arm in ['R11','R11_NOMINAL']:failure(rid,arm,'inference')
        if (RUN/'ml_prefix'/rid/'COMPLETE.json').exists() and not all((dest/arm/'prediction.json').exists() for arm in ['ET_REFERENCE','ET_CANDIDATE']):
            if worker('ml',rid):
                for arm in ['ET_REFERENCE','ET_CANDIDATE']:failure(rid,arm,'inference')
        if not (dest/'CHEN2016/prediction.json').exists() and worker('chen',rid):failure(rid,'CHEN2016','inference')
        save(RUN/'RECORD_PROGRESS.json',dict(completed=sum((DATA/'predictions'/x['id']/'CHEN2016/prediction.json').exists() for x in records),intended_observed=len(records),last_record=rid))
    verify()
    call('evaluate',[sys.executable,'-B','-X','utf8',HERE/'evaluate.py'])
    call('paper',[sys.executable,'-B','-X','utf8',HERE/'paper.py'])
    save(RUN/'COMPLETE.json',dict(status='COMPLETE_WITH_ALL_INTENDED_DENOMINATORS',finished_utc=datetime.now(timezone.utc).isoformat(),models_retuned=False))
    save(RUN/'PROGRESS.json',dict(stage='complete',status='COMPLETE'))
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('stage',choices=['seal','verify','stage','run']);x=a.parse_args()
    try:globals()[x.stage]()
    except Exception as e:
        save(RUN/'BLOCKER.json',dict(stage=x.stage,error=str(e),traceback=traceback.format_exc(),models_retuned=False));raise
